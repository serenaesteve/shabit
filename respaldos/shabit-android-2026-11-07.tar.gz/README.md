# shabit

**Descarga y presentación:** https://shabit.serenaesteve.com · **iPhone:** https://shabit.serenaesteve.com/app/

Aplicación Android para registrar hábitos diarios, ponerles objetivos y consultar el progreso.

Cada hábito tiene un **color de disco** de competición. Cada día cumplido **carga un disco en su barra**; los días de descanso son discos de descarga, que no suman pero tampoco rompen la racha. En la pantalla de progreso, cada semana es una pila de discos junto a la línea del objetivo.

| Hoy | Progreso | Ficha de un hábito | Plan |
|---|---|---|---|
| ![](docs/capturas/01-hoy.png) | ![](docs/capturas/02-progreso.png) | ![](docs/capturas/04-calendario.png) | ![](docs/capturas/05-plan.png) |

| Goma (modo oscuro) | | Widget | Ajustes |
|---|---|---|---|
| ![](docs/capturas/07-hoy-goma.png) | ![](docs/capturas/08-progreso-goma.png) | ![](docs/capturas/10-widget.png) | ![](docs/capturas/09-ajustes.png) |

## Qué hace

- **Registrar.** En *Hoy* cada hábito es una barra con los últimos 7 días.
  - Tocar un hueco carga el disco (cae sobre la barra con un pequeño rebote y vibra) y volver a tocarlo lo quita.
  - Mantenerlo pulsado marca **descanso**.
  - El botón *Hoy descanso* marca como descanso todo lo que quede pendiente del día, por ejemplo si estás enfermo.
- **Objetivos.** Cada hábito tiene:
  - un **objetivo semanal** de 1 a 7 días;
  - una **meta total** de discos (21, 30, 66, 100 o 365);
  - opcionalmente, un **objetivo de pasos** (de 4.000 a 12.000), que marca el día solo;
  - opcionalmente, un **aviso diario**. El aviso no salta si el día ya está hecho o es de descanso, y trae un botón *Hecho*.
- **Progreso.** Para cada hábito se ven:
  - pilas de discos por semana con la línea del objetivo;
  - racha (en días si el objetivo es diario y en semanas si no lo es);
  - récord;
  - constancia (porcentaje de semanas cumplidas en las últimas 12);
  - una barra de meta.

  La ficha añade un calendario mensual para corregir días pasados.
- **Widget** en la pantalla de inicio con los hábitos de hoy. Un toque carga el disco sin abrir la app.
- **Ajustes:** suelo claro (magnesio), oscuro (goma) o el del sistema; semana que empieza en lunes o en domingo; vibración; y hábitos guardados aparte sin perder el historial.

Los datos se guardan solo en el móvil. La app no usa internet.

### Días de descanso

Un descanso no cuenta como día cumplido, pero:
- **no rompe la racha de días**: hecho, descanso, hecho cuenta como 2 seguidos;
- **rebaja el objetivo de su semana**: con un objetivo de 5 y 3 descansos, esa semana basta con 4;
- una **semana entera de descanso** (vacaciones) no cuenta: ni suma ni rompe la racha de semanas.

### Pasos

| Móvil | Cómo se cuentan |
|---|---|
| Con contador de pasos (`TYPE_STEP_COUNTER`, la mayoría) | Siempre, aunque la app esté cerrada. Un trabajo de WorkManager lee el contador cada 15 minutos y marca el hábito al llegar al objetivo. Necesita el permiso de actividad física. |
| Sin contador | Con el **acelerómetro**, detectando los picos de cada paso, mientras la app está abierta. No necesita permiso. |
| Sin sensores | La opción de pasos se oculta. |

El contador del sistema suma los pasos desde que se encendió el móvil. Por eso la app guarda el valor del inicio del día y lo resta, y si el móvil se reinicia, conserva lo contado hasta entonces.

El hábito se marca solo **una vez al día**: si luego lo quitas a mano, no vuelve a marcarse, y nunca pisa un descanso.

## Tecnología

| Parte | Cómo |
|---|---|
| Interfaz | Kotlin 2.0 y Jetpack Compose. Todos los dibujos (suelo de goma, discos de lado y de frente, pilas, barra moleteada) se hacen con `Canvas`. Tipografía Barlow y Barlow Condensed (licencia OFL). |
| Persistencia | Room. Tabla `habitos` y tabla `registros`, cuya clave es hábito + día y su tipo, `HECHO` o `DESCANSO`. El esquema se exporta en `app/schemas`. |
| Preferencias | DataStore: una tienda para los ajustes y otra para el estado del podómetro. |
| Sensores | `SensorManager` con `TYPE_STEP_COUNTER` o, si no lo hay, `TYPE_ACCELEROMETER` y un detector de pasos propio (`dominio/Pasos.kt`). |
| Segundo plano | WorkManager: un aviso diario por hábito y la lectura del podómetro cada 15 minutos, que de paso refresca el widget después de medianoche. |
| Widget | Jetpack Glance. Lee los flujos de Room, así que se actualiza solo cuando cambia algo desde la app, el widget, la notificación o el podómetro. |
| Arquitectura | Una actividad, Navigation Compose y un `AndroidViewModel` que combina los flujos de Room, DataStore, el podómetro y la fecha, que cambia sola a medianoche. Las rachas, la constancia y los pasos están en Kotlin puro para probarlos sin Android. |

```
app/src/main/java/com/serenaesteve/carga/
├── ShabitApp.kt              contenedor de dependencias, canal de avisos y trabajo de pasos
├── MainActivity.kt          tema, barras del sistema y navegación
├── datos/                   Room (Habito, Registro, HabitoDao, BaseDatos), Repositorio, Preferencias
├── dominio/                 Progreso (rachas con descansos), Ficha y Pasos (contador y detector)
├── pasos/                   Podometro (sensores y estado) y PasosWorker
├── recordatorios/           Recordatorios, RecordatorioWorker y HechoReceiver
├── widget/                  WidgetHoy (Glance), su receptor y la acción de cargar
└── iu/
    ├── ShabitViewModel.kt
    ├── BarraNavegacion.kt   barra olímpica moleteada con collarín en la pestaña activa
    ├── gimnasio/            piezas dibujadas
    ├── tema/                suelos, colores de disco y tipografía
    └── pantallas/           Hoy, Progreso, Detalle, Plan y Ajustes
```

## Permisos

| Permiso | Para qué | Cuándo se pide |
|---|---|---|
| `POST_NOTIFICATIONS` | Avisos diarios | Al poner una hora de aviso (Android 13 o superior). |
| `ACTIVITY_RECOGNITION` | Contador de pasos | Al elegir un objetivo de pasos, o desde *Hoy* si falta (Android 10 o superior). Con el acelerómetro no hace falta. |
| `VIBRATE` | Vibración al cargar un disco | Permiso normal. Se puede desactivar en Ajustes. |

WorkManager añade además `WAKE_LOCK`, `RECEIVE_BOOT_COMPLETED`, `FOREGROUND_SERVICE` y `ACCESS_NETWORK_STATE` para lanzar los avisos a su hora. La app no pide `INTERNET`.

Los sensores están declarados como `required="false"`, así que la app se instala también en móviles sin ellos. Si se deniega un permiso, la app sigue funcionando y explica qué se pierde.

## Compilar e instalar

Requisitos: JDK 17 y Android SDK con la plataforma 35.

```bash
./gradlew testDebugUnitTest      # 18 pruebas
./gradlew lintDebug              # 0 errores, 0 avisos
./gradlew assembleDebug
./gradlew assembleRelease        # firmado si existe firma.properties; R8, unos 2,4 MB
```

`firma.properties` (fuera de git) apunta al almacén de claves:

```properties
almacen=shabit.jks
clave=...
alias=shabit
claveAlias=...
```

Para instalarlo en un móvil real: copiar `shabit-1.0.apk` y abrirlo permitiendo *instalar apps desconocidas*, o usar `adb install` con la depuración USB activada.

## Pruebas

**Unitarias** (`app/src/test`, 18):
- Rachas de días y de semanas, con y sin descansos.
- Objetivo semanal rebajado por los descansos y semana entera de vacaciones.
- Semana de creación incompleta y constancia.
- Pasos: base del día, cambio de día y reinicio del móvil.
- Detector de pasos: 10 s caminando a 2 pasos por segundo dan unos 20 pasos, y con el móvil quieto, 0.
- Hora del próximo aviso.

**En emulador** (Pixel 7, Android 15, sin contador de pasos):
- Cargar y quitar discos, marcar descanso con pulsación larga y comprobar que el objetivo de la semana baja de 5 a 4.
- Sumar 8.050 pasos: el hábito *Caminar* se marca solo. Quitarlo a mano y sumar más pasos: no se vuelve a marcar.
- Inyectar 12 movimientos en el acelerómetro con `adb emu sensor set acceleration`: se cuentan exactamente 12 pasos.
- Poner el widget en la pantalla de inicio y cargar dos hábitos desde él: se guardan y el widget se actualiza.
- Aviso: no salta en un día de descanso. Al quitar el descanso salta, y el botón *Hecho* guarda el día.
- Modo oscuro, Ajustes y el APK de publicación reducido con R8.

**Herramientas de desarrollo.** Solo existen en la versión *debug*:

```bash
adb shell am broadcast -n com.serenaesteve.shabit/.DemoReceiver                 # 14 semanas de datos de ejemplo
adb shell am broadcast -n com.serenaesteve.shabit/.DemoReceiver --ei pasos 500  # suma pasos detectados
adb shell am broadcast -n com.serenaesteve.shabit/.DemoReceiver --el aviso 2    # lanza ya el aviso del hábito 2
```

## Relación con 0489, RA2 (desarrollo de aplicaciones para móviles)

| Criterio | Dónde |
|---|---|
| a) Estructura de clases | Capas `datos`, `dominio`, `pasos`, `recordatorios`, `widget` e `iu` |
| b) Ventanas, menús, alertas y controles | Pantallas de Compose, `AlertDialog` al borrar, `TimePickerDialog`, controles propios con pulsación corta y larga, y widget |
| d) Sensores | Contador de pasos y acelerómetro con detector propio |
| f) Persistencia | Room y DataStore |
| g) Pruebas de interacción en emulador | Recorrido de *Pruebas*, con inyección de datos en el sensor del emulador |
| h) Empaquetado | APK firmado y reducido con R8 |
| i) Documentación | Este README |
| j) Permisos | `POST_NOTIFICATIONS` y `ACTIVITY_RECOGNITION` en tiempo de ejecución, y `VIBRATE` |

Fuera del alcance: conexiones inalámbricas (c) y HTTP (e).

## Web

La página de presentación y descarga está en `web/`: HTML y CSS sin dependencias, la barra interactiva en `barra.js`, las capturas en WebP y las fuentes recortadas en WOFF2. Se publica en https://shabit.serenaesteve.com con:

```bash
./gradlew assembleRelease && cp app/build/outputs/apk/release/app-release.apk web/shabit-1.0.apk
bash despliegue/desplegar.sh        # copia web/ a /var/www/shabit, configura Apache y el certificado
```

Si cambia el APK, hay que actualizar también las dos huellas SHA-256 de `web/index.html` (`sha256sum` y `apksigner verify --print-certs`).

## iPhone (web app)

En iPhone, shabit es una web app instalable en `web/app/`: se abre en Safari y se añade a la pantalla de inicio. No necesita Mac, cuenta de Apple ni App Store. Es JavaScript sin dependencias ni compilación:

| Archivo | Qué hace |
|---|---|
| `js/progreso.js` | Rachas, descansos, objetivo semanal y constancia. Es la misma lógica que `Progreso.kt`, y se prueba con los mismos casos. |
| `js/pasos.js` | Detector de pasos con el acelerómetro (`DeviceMotion`), el mismo que usa Android cuando no hay contador. |
| `js/almacen.js` | Datos en `localStorage` dentro del iPhone, con copia de seguridad para exportar e importar en JSON. |
| `js/dibujo.js` | Discos, pilas y disco resumen en SVG. |
| `js/vistas.js`, `js/main.js` | Pantallas, navegación, pulsación larga, cambio de día a medianoche. |
| `sw.js`, `manifest.webmanifest` | Instalación y funcionamiento sin conexión. Al cambiar algún archivo hay que subir `VERSION` en `sw.js`. |

Diferencias con Android, por límites de Safari:
- los pasos se cuentan solo con la app abierta, tras dar permiso de movimiento;
- no hay widget;
- de momento no hay avisos diarios: en iPhone necesitan notificaciones push desde un servidor.

`?demo` carga datos de ejemplo si no hay ningún hábito.

Pruebas en WebKit, el motor de Safari, con un iPhone 13 emulado. Comprueban la lógica, los toques, la pulsación larga, los pasos, la copia de seguridad y el modo sin conexión:

```bash
/root/life-dashboard/.venv/bin/python pruebas-web/pruebas.py [carpeta-capturas]
```
