package com.serenaesteve.shabit.iu

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.selection.selectable
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import com.serenaesteve.shabit.iu.tema.Letra
import com.serenaesteve.shabit.iu.tema.LocalSuelo

/**
 * Barra de navegación: una barra olímpica moleteada de lado a lado. La pestaña
 * elegida lleva su collarín, como el cierre que sujeta los discos.
 */
@Composable
fun BarraNavegacion(actual: String, ir: (String) -> Unit) {
    val s = LocalSuelo.current
    val destinos = listOf("hoy" to "Hoy", "progreso" to "Progreso")
    val acero = Color(0xFFB9BEC5)
    Box(
        Modifier
            .fillMaxWidth()
            .drawBehind {
                drawRect(s.franja)
                val y = 10.dp.toPx()
                val g = 7.dp.toPx()
                drawRect(acero, Offset(0f, y - g / 2), Size(size.width, g))
                // Moleteado: rayas cruzadas finas sobre la barra.
                var x = 0f
                val paso = 3.dp.toPx()
                while (x < size.width) {
                    drawLine(Color(0xFF7D838B), Offset(x, y - g / 2), Offset(x + g, y + g / 2), 0.8f)
                    drawLine(Color(0xFF7D838B), Offset(x + g, y - g / 2), Offset(x, y + g / 2), 0.8f)
                    x += paso
                }
            }
            .navigationBarsPadding(),
    ) {
        Row(Modifier.fillMaxWidth().height(66.dp)) {
            destinos.forEach { (ruta, texto) ->
                val elegido = actual == ruta
                Box(
                    Modifier.weight(1f).height(66.dp).selectable(elegido, role = Role.Tab) { ir(ruta) },
                    contentAlignment = Alignment.Center,
                ) {
                    if (elegido) {
                        Canvas(Modifier.align(Alignment.TopCenter).height(22.dp).fillMaxWidth()) {
                            val w = 46.dp.toPx()
                            drawRect(Color(0xFF2B2E33), Offset(center.x - w / 2, 0f), Size(w, 20.dp.toPx()))
                            drawRect(acero, Offset(center.x - w / 2, 2.dp.toPx()), Size(w, 3.dp.toPx()))
                            drawRect(Color(0xFFD7262E), Offset(center.x + w / 2 - 8.dp.toPx(), 7.dp.toPx()), Size(4.dp.toPx(), 8.dp.toPx()))
                        }
                    }
                    Text(
                        texto.uppercase(), style = Letra.dato,
                        color = Color(0xFFF1F0EC).copy(alpha = if (elegido) 1f else 0.5f),
                        modifier = Modifier.padding(top = 18.dp),
                    )
                }
            }
        }
    }
}
