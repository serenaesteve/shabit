package com.serenaesteve.shabit.dominio

import kotlin.math.sqrt

/**
 * Estado del contador de pasos del día. El sensor TYPE_STEP_COUNTER da los
 * pasos acumulados desde que se encendió el móvil, así que se guarda el valor
 * del primer momento del día ([base]) y se resta. Si el móvil se reinicia, el
 * contador vuelve a 0 y lo contado hasta entonces pasa a [acumulado].
 */
data class EstadoPasos(
    val dia: Long = -1,
    val base: Float = 0f,
    val ultimo: Float = 0f,
    val acumulado: Int = 0,
    /** Pasos detectados con el acelerómetro en móviles sin contador. */
    val detectados: Int = 0,
)

object Pasos {
    fun conContador(e: EstadoPasos, valor: Float, hoy: Long): EstadoPasos = when {
        e.dia != hoy -> EstadoPasos(dia = hoy, base = valor, ultimo = valor)
        valor < e.ultimo -> e.copy(acumulado = e.acumulado + (e.ultimo - e.base).toInt(), base = 0f, ultimo = valor)
        else -> e.copy(ultimo = valor)
    }

    fun conDetector(e: EstadoPasos, nuevos: Int, hoy: Long): EstadoPasos =
        if (e.dia != hoy) EstadoPasos(dia = hoy, detectados = nuevos)
        else e.copy(detectados = e.detectados + nuevos)

    fun deHoy(e: EstadoPasos, hoy: Long): Int =
        if (e.dia != hoy) 0 else e.acumulado + (e.ultimo - e.base).toInt() + e.detectados
}

/**
 * Detector de pasos para móviles sin contador: busca picos en la aceleración.
 * Un paso es subir por encima de [alto] después de haber bajado de [bajo]
 * (histéresis para no contar dos veces el mismo pico), con al menos [minimoMs]
 * entre pasos, que es más rápido de lo que nadie camina.
 */
class DetectorPasos(
    private val alto: Float = 11.2f,
    private val bajo: Float = 9.0f,
    private val minimoMs: Long = 260,
) {
    private var armado = true
    private var ultimoPaso = Long.MIN_VALUE / 2
    private var suave = 9.81f

    /** Devuelve true si esta muestra completa un paso. */
    fun muestra(x: Float, y: Float, z: Float, tiempoMs: Long): Boolean {
        val m = sqrt(x * x + y * y + z * z)
        suave = suave * 0.4f + m * 0.6f
        if (armado && suave > alto && tiempoMs - ultimoPaso >= minimoMs) {
            armado = false
            ultimoPaso = tiempoMs
            return true
        }
        if (suave < bajo) armado = true
        return false
    }
}
