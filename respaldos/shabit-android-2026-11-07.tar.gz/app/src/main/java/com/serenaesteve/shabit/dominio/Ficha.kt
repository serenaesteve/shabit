package com.serenaesteve.shabit.dominio

import com.serenaesteve.shabit.datos.Dias
import com.serenaesteve.shabit.datos.Habito
import java.time.DayOfWeek
import java.time.LocalDate

/** Un hábito con su progreso ya calculado, listo para pintarse. */
data class Ficha(
    val habito: Habito,
    val hechos: Set<Long>,
    val descansos: Set<Long>,
    val estaSemana: Int,
    /** Objetivo de esta semana descontando los descansos; null si toda la semana es descanso. */
    val objetivoSemana: Int?,
    /** Si el objetivo es diario, la racha se mide en días; si no, en semanas. */
    val rachaEnDias: Boolean,
    val racha: Int,
    val mejorRacha: Int,
    val constancia: Float?,
) {
    val total: Int get() = hechos.size
    val semanaCumplida: Boolean get() = objetivoSemana != null && estaSemana >= objetivoSemana
    val metaCumplida: Boolean get() = total >= habito.meta

    companion object {
        fun de(habito: Habito, dias: Dias, hoy: LocalDate, primerDia: DayOfWeek): Ficha {
            val (h, d) = dias
            val diario = habito.objetivoSemanal >= 7
            val o = habito.objetivoSemanal
            val inicio = Progreso.inicioEfectivo(h, d, habito.creado)
            return Ficha(
                habito = habito,
                hechos = h,
                descansos = d,
                estaSemana = Progreso.hechasEstaSemana(h, hoy, primerDia),
                objetivoSemana = Progreso.objetivoDeSemana(Progreso.inicioSemana(hoy, primerDia), inicio, o, d),
                rachaEnDias = diario,
                racha = if (diario) Progreso.rachaDias(h, d, hoy)
                else Progreso.rachaSemanas(h, d, hoy, o, primerDia, habito.creado),
                mejorRacha = if (diario) Progreso.mejorRachaDias(h, d)
                else Progreso.mejorRachaSemanas(h, d, hoy, o, primerDia, habito.creado),
                constancia = Progreso.constancia(h, d, hoy, o, primerDia, habito.creado),
            )
        }
    }
}
