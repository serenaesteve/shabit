package com.serenaesteve.shabit.recordatorios

import android.Manifest
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.serenaesteve.shabit.MainActivity
import com.serenaesteve.shabit.ShabitApp
import com.serenaesteve.shabit.R
import java.time.LocalDate

/** Se ejecuta en segundo plano a la hora del recordatorio y avisa si el día sigue sin marcar. */
class RecordatorioWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val id = inputData.getLong(HABITO, -1)
        val repo = (applicationContext as ShabitApp).repositorio
        val habito = repo.habito(id)
        if (habito == null || habito.archivado || habito.recordatorio == null) {
            Recordatorios.cancelar(applicationContext, id)
            return Result.success()
        }
        val hoy = LocalDate.now().toEpochDay()
        if (repo.tipo(id, hoy) != null) return Result.success()

        // Antes de Android 13 no existe el permiso: avisar siempre está permitido.
        val permitido = android.os.Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(
            applicationContext, Manifest.permission.POST_NOTIFICATIONS,
        ) == PackageManager.PERMISSION_GRANTED
        if (!permitido) return Result.success()

        val abrir = PendingIntent.getActivity(
            applicationContext, id.toInt(),
            Intent(applicationContext, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val hecho = PendingIntent.getBroadcast(
            applicationContext, id.toInt(),
            Intent(applicationContext, HechoReceiver::class.java)
                .putExtra(HechoReceiver.HABITO, id)
                .putExtra(HechoReceiver.DIA, hoy),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val aviso = NotificationCompat.Builder(applicationContext, ShabitApp.CANAL_RECORDATORIOS)
            .setSmallIcon(R.drawable.ic_notificacion)
            .setContentTitle(habito.nombre)
            .setContentText(applicationContext.getString(R.string.aviso_texto))
            .setContentIntent(abrir)
            .setAutoCancel(true)
            .addAction(0, applicationContext.getString(R.string.aviso_hecho), hecho)
            .build()
        NotificationManagerCompat.from(applicationContext).notify(id.toInt(), aviso)
        return Result.success()
    }

    companion object {
        const val HABITO = "habito"
    }
}
