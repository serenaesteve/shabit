package com.serenaesteve.shabit

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.statusBars
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.serenaesteve.shabit.iu.BarraNavegacion
import com.serenaesteve.shabit.iu.ShabitViewModel
import com.serenaesteve.shabit.iu.gimnasio.goma
import com.serenaesteve.shabit.iu.pantallas.Ajustes
import com.serenaesteve.shabit.iu.pantallas.Detalle
import com.serenaesteve.shabit.iu.pantallas.Hoy
import com.serenaesteve.shabit.iu.pantallas.Plan
import com.serenaesteve.shabit.iu.pantallas.Progreso
import com.serenaesteve.shabit.iu.tema.ShabitTema
import com.serenaesteve.shabit.iu.tema.LocalSuelo

class MainActivity : ComponentActivity() {
    private val vm: ShabitViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val estado by vm.estado.collectAsStateWithLifecycle()
            ShabitTema(estado.ajustes.tema) {
                val s = LocalSuelo.current
                LaunchedEffect(s.oscuro) {
                    val arriba = if (s.oscuro) SystemBarStyle.dark(s.fondo.toArgb())
                    else SystemBarStyle.light(s.fondo.toArgb(), s.tinta.toArgb())
                    enableEdgeToEdge(statusBarStyle = arriba, navigationBarStyle = SystemBarStyle.dark(s.franja.toArgb()))
                }
                App(vm)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        vm.refrescar()
    }
}

@Composable
private fun App(vm: ShabitViewModel) {
    val estado by vm.estado.collectAsStateWithLifecycle()
    val nav = rememberNavController()
    val entrada by nav.currentBackStackEntryAsState()
    val ruta = entrada?.destination?.route
    val principal = ruta == "hoy" || ruta == "progreso"
    val s = LocalSuelo.current
    val arriba = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val relleno = PaddingValues(top = arriba, bottom = 24.dp)
    val pedirActividad = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { vm.refrescar() }
    val pedirPasos = {
        if (Build.VERSION.SDK_INT >= 29) pedirActividad.launch(Manifest.permission.ACTIVITY_RECOGNITION)
    }

    Column(Modifier.fillMaxSize().goma(s)) {
        Box(Modifier.weight(1f)) {
            NavHost(nav, startDestination = "hoy", enterTransition = { fadeIn() }, exitTransition = { fadeOut() }) {
                composable("hoy") {
                    Hoy(
                        estado,
                        alternar = vm::alternar,
                        descansoHoy = { vm.descansoHoy() },
                        abrirFicha = { nav.navigate("ficha/$it") },
                        nuevo = { nombre, pasos ->
                            nav.navigate("plan?id=0&nombre=${android.net.Uri.encode(nombre.orEmpty())}&pasos=${pasos ?: 0}")
                        },
                        ajustes = { nav.navigate("ajustes") },
                        pedirPermisoPasos = pedirPasos,
                        relleno = relleno,
                    )
                }
                composable("progreso") { Progreso(estado, abrirFicha = { nav.navigate("ficha/$it") }, relleno = relleno) }
                composable("ficha/{id}", listOf(navArgument("id") { type = NavType.LongType })) { e ->
                    val id = e.arguments?.getLong("id") ?: 0L
                    Detalle(estado, id, vm::alternar, editar = { nav.navigate("plan?id=$id") }, volver = { nav.popBackStack() }, relleno = relleno)
                }
                composable(
                    "plan?id={id}&nombre={nombre}&pasos={pasos}",
                    listOf(
                        navArgument("id") { type = NavType.LongType; defaultValue = 0L },
                        navArgument("nombre") { type = NavType.StringType; defaultValue = "" },
                        navArgument("pasos") { type = NavType.IntType; defaultValue = 0 },
                    ),
                ) { e ->
                    val id = e.arguments?.getLong("id") ?: 0L
                    val existente = estado.ficha(id)?.habito
                    if (id != 0L && existente == null) return@composable
                    Plan(
                        existente = existente,
                        nombreInicial = e.arguments?.getString("nombre"),
                        pasosIniciales = e.arguments?.getInt("pasos")?.takeIf { it > 0 },
                        hoy = estado.hoy,
                        pasos = estado.pasos,
                        guardar = { h -> vm.guardar(h) { nav.popBackStack() } },
                        archivar = { h -> vm.archivar(h, true); volverAHoy(nav) },
                        borrar = { h -> vm.borrar(h); volverAHoy(nav) },
                        permisoPasosCambiado = { vm.refrescar() },
                        volver = { nav.popBackStack() },
                        relleno = relleno,
                    )
                }
                composable("ajustes") {
                    Ajustes(
                        estado, tema = vm::tema, semanaEnDomingo = vm::semanaEnDomingo, vibracion = vm::vibracion,
                        recuperar = { vm.archivar(it, false) }, volver = { nav.popBackStack() }, relleno = relleno,
                    )
                }
            }
            // Franja bajo la barra de estado para que el contenido no se mezcle con la hora.
            Box(Modifier.fillMaxWidth().height(arriba).goma(s))
        }
        if (principal) {
            BarraNavegacion(ruta!!) { destino ->
                nav.navigate(destino) {
                    popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                    launchSingleTop = true
                    restoreState = true
                }
            }
        }
    }
}

private fun volverAHoy(nav: NavHostController) {
    nav.navigate("hoy") { popUpTo("hoy") { inclusive = true } }
}
