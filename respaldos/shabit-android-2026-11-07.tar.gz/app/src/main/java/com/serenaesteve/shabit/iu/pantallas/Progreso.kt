package com.serenaesteve.shabit.iu.pantallas

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.serenaesteve.shabit.datos.Tipo
import com.serenaesteve.shabit.dominio.Ficha
import com.serenaesteve.shabit.dominio.Progreso
import com.serenaesteve.shabit.iu.EstadoShabit
import com.serenaesteve.shabit.iu.gimnasio.BarraMeta
import com.serenaesteve.shabit.iu.gimnasio.PilasSemanas
import com.serenaesteve.shabit.iu.gimnasio.Separador
import com.serenaesteve.shabit.iu.gimnasio.discoDeFrente
import com.serenaesteve.shabit.iu.racha
import com.serenaesteve.shabit.iu.tema.Letra
import com.serenaesteve.shabit.iu.tema.LocalSuelo
import com.serenaesteve.shabit.iu.tema.colorDisco
import kotlin.math.roundToInt

@Composable
fun Progreso(estado: EstadoShabit, abrirFicha: (Long) -> Unit, relleno: PaddingValues) {
    val s = LocalSuelo.current
    val fichas = estado.fichas
    val cumplidas = fichas.count { it.semanaCumplida }
    val total = fichas.sumOf { it.total }
    val mejorViva = fichas.maxByOrNull { it.racha }?.takeIf { it.racha > 0 }

    LazyColumn(contentPadding = relleno, modifier = Modifier.fillMaxWidth()) {
        item {
            Column(Modifier.padding(horizontal = 20.dp).padding(top = 20.dp)) {
                Text("TUS SEMANAS", style = Letra.etiqueta, color = s.tintaSuave)
                Text("PROGRESO", style = Letra.portada, color = s.tinta, modifier = Modifier.semantics { heading() })
                Spacer(Modifier.height(18.dp))
                if (fichas.isEmpty()) {
                    Text(
                        "Aquí verás tus semanas apiladas en cuanto empieces a cargar discos en Hoy.",
                        style = Letra.cuerpo, color = s.tintaSuave,
                    )
                } else {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Cifra("$cumplidas/${fichas.size}", "objetivos\nesta semana")
                        Cifra("$total", "discos\nen total")
                        Cifra(
                            mejorViva?.racha?.toString() ?: "0",
                            mejorViva?.let { "${if (it.rachaEnDias) "días" else "semanas"} de racha\n${it.habito.nombre.lowercase()}" }
                                ?: "rachas\nactivas",
                        )
                    }
                }
                Spacer(Modifier.height(18.dp))
                Separador(Modifier.fillMaxWidth().height(2.dp))
            }
        }
        items(fichas, key = { it.habito.id }) { ficha ->
            BloqueHabito(ficha, estado) { abrirFicha(ficha.habito.id) }
        }
    }
}

@Composable
private fun Cifra(valor: String, texto: String) {
    val s = LocalSuelo.current
    Column(Modifier.width(104.dp)) {
        Text(valor, style = Letra.cifra, color = s.tinta)
        Text(texto.uppercase(), style = Letra.etiqueta, color = s.tintaSuave, maxLines = 3)
    }
}

@Composable
private fun BloqueHabito(ficha: Ficha, estado: EstadoShabit, abrir: () -> Unit) {
    val s = LocalSuelo.current
    val h = ficha.habito
    val color = colorDisco(h.color)
    val desde = Progreso.inicioEfectivo(ficha.hechos, ficha.descansos, h.creado)
    Column(
        Modifier.fillMaxWidth().clickable(onClick = abrir).padding(horizontal = 20.dp).padding(top = 20.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Canvas(Modifier.size(22.dp)) { discoDeFrente(center, size.minDimension / 2, color, Tipo.HECHO, s) }
            Spacer(Modifier.width(10.dp))
            Text(h.nombre.uppercase(), style = Letra.nombre, color = s.tinta, modifier = Modifier.weight(1f))
            Text("VER ›", style = Letra.etiqueta, color = s.tintaSuave)
        }
        Spacer(Modifier.height(10.dp))
        PilasSemanas(
            ficha.hechos, ficha.descansos, estado.hoy, estado.ajustes.primerDia, desde, h.objetivoSemanal, color,
            Modifier
                .fillMaxWidth()
                .height(96.dp)
                .semantics { contentDescription = "Últimas semanas de ${h.nombre}: ${ficha.total} días cumplidos" },
        )
        Text("OBJETIVO ${h.objetivoSemanal}/SEMANA  ·  CADA COLUMNA ES UNA SEMANA", style = Letra.etiqueta, color = s.tintaSuave)
        Spacer(Modifier.height(14.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Dato("RACHA", racha(ficha.racha, ficha.rachaEnDias))
            Dato("RÉCORD", racha(ficha.mejorRacha, ficha.rachaEnDias))
            Dato("CONSTANCIA", ficha.constancia?.let { "${(it * 100).roundToInt()} %" } ?: "—")
        }
        Spacer(Modifier.height(12.dp))
        Meta(ficha, color)
        Spacer(Modifier.height(16.dp))
        Separador(Modifier.fillMaxWidth().height(2.dp))
    }
}

@Composable
fun Dato(etiqueta: String, valor: String) {
    val s = LocalSuelo.current
    Column {
        Text(etiqueta, style = Letra.etiqueta, color = s.tintaSuave)
        Text(valor.uppercase(), style = Letra.dato, color = s.tinta)
    }
}

@Composable
fun Meta(ficha: Ficha, color: Color) {
    val s = LocalSuelo.current
    val h = ficha.habito
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text("META", style = Letra.etiqueta, color = s.tintaSuave, modifier = Modifier.width(46.dp))
        BarraMeta(ficha.total / h.meta.toFloat(), color, Modifier.weight(1f).height(14.dp))
        Spacer(Modifier.width(10.dp))
        Text(
            if (ficha.metaCumplida) "${ficha.total}/${h.meta} ✓" else "${ficha.total}/${h.meta}",
            style = Letra.dato, color = if (ficha.metaCumplida) color else s.tinta,
        )
    }
}
