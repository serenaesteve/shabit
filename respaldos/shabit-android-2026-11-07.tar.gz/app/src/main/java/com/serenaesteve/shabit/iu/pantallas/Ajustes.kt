package com.serenaesteve.shabit.iu.pantallas

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import com.serenaesteve.shabit.BuildConfig
import com.serenaesteve.shabit.datos.Habito
import com.serenaesteve.shabit.datos.Tema
import com.serenaesteve.shabit.datos.Tipo
import com.serenaesteve.shabit.iu.EstadoShabit
import com.serenaesteve.shabit.iu.gimnasio.Boton
import com.serenaesteve.shabit.iu.gimnasio.Separador
import com.serenaesteve.shabit.iu.gimnasio.discoDeFrente
import com.serenaesteve.shabit.iu.tema.Letra
import com.serenaesteve.shabit.iu.tema.LocalSuelo
import com.serenaesteve.shabit.iu.tema.colorDisco
import com.serenaesteve.shabit.pasos.FuentePasos
import java.time.DayOfWeek

@Composable
fun Ajustes(
    estado: EstadoShabit,
    tema: (Tema) -> Unit,
    semanaEnDomingo: (Boolean) -> Unit,
    vibracion: (Boolean) -> Unit,
    recuperar: (Habito) -> Unit,
    volver: () -> Unit,
    relleno: PaddingValues,
) {
    val s = LocalSuelo.current
    val a = estado.ajustes
    Column(Modifier.verticalScroll(rememberScrollState()).padding(relleno).padding(horizontal = 20.dp)) {
        Text("‹ VOLVER", style = Letra.etiqueta, color = s.tintaSuave, modifier = Modifier.clickable(onClick = volver).padding(vertical = 12.dp))
        Text("AJUSTES", style = Letra.portada, color = s.tinta)

        Grupo("SUELO")
        listOf(Tema.SISTEMA to "Como el sistema", Tema.MAGNESIO to "Magnesio (claro)", Tema.GOMA to "Goma (oscuro)").forEach { (t, texto) ->
            Opcion(texto, a.tema == t, Role.RadioButton) { tema(t) }
        }

        Grupo("SEMANA")
        Opcion("Empieza el lunes", a.primerDia == DayOfWeek.MONDAY, Role.RadioButton) { semanaEnDomingo(false) }
        Opcion("Empieza el domingo", a.primerDia == DayOfWeek.SUNDAY, Role.RadioButton) { semanaEnDomingo(true) }

        Grupo("TACTO")
        Opcion("Vibrar al cargar un disco", a.vibracion, Role.Checkbox) { vibracion(!a.vibracion) }

        Grupo("PASOS")
        Text(
            when (estado.pasos.fuente) {
                FuentePasos.CONTADOR -> "Este móvil tiene contador de pasos: se cuentan siempre, aunque la app esté cerrada."
                FuentePasos.ACELEROMETRO -> "Este móvil no tiene contador de pasos. Se detectan con el acelerómetro mientras la app está abierta."
                FuentePasos.NINGUNA -> "Este móvil no tiene sensores para contar pasos."
            },
            style = Letra.nota, color = s.tintaSuave,
        )

        Grupo("GUARDADOS APARTE")
        if (estado.guardados.isEmpty()) Text("No hay hábitos guardados aparte.", style = Letra.cuerpo, color = s.tintaSuave)
        estado.guardados.forEach { h ->
            Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Canvas(Modifier.size(22.dp)) { discoDeFrente(center, size.minDimension / 2, colorDisco(h.color), Tipo.HECHO, s) }
                Spacer(Modifier.width(10.dp))
                Text(h.nombre, style = Letra.cuerpo, color = s.tinta, modifier = Modifier.weight(1f))
                Boton("Recuperar", { recuperar(h) })
            }
        }

        Grupo("ACERCA DE")
        Text(
            "shabit ${BuildConfig.VERSION_NAME}. Tus hábitos se guardan solo en este móvil, en una base de datos local; la app no usa internet.",
            style = Letra.cuerpo, color = s.tintaSuave,
        )
        Spacer(Modifier.height(40.dp))
    }
}

@Composable
private fun Grupo(texto: String) {
    val s = LocalSuelo.current
    Spacer(Modifier.height(26.dp))
    Text(texto, style = Letra.etiqueta, color = s.tintaSuave)
    Spacer(Modifier.height(4.dp))
    Separador(Modifier.fillMaxWidth().height(1.dp))
    Spacer(Modifier.height(4.dp))
}

@Composable
private fun Opcion(texto: String, activa: Boolean, rol: Role, alTocar: () -> Unit) {
    val s = LocalSuelo.current
    val modo = if (rol == Role.Checkbox) Modifier.toggleable(activa, role = rol) { alTocar() }
    else Modifier.selectable(activa, role = rol, onClick = alTocar)
    Row(Modifier.fillMaxWidth().then(modo).padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Canvas(Modifier.size(26.dp)) { discoDeFrente(center, size.minDimension / 2, s.tinta, if (activa) Tipo.HECHO else null, s) }
        Spacer(Modifier.width(12.dp))
        Text(texto, style = Letra.cuerpo, color = s.tinta)
    }
}
