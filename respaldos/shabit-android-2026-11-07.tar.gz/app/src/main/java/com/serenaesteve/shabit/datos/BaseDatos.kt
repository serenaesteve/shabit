package com.serenaesteve.shabit.datos

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters

class Conversores {
    @TypeConverter fun deTipo(t: Tipo): String = t.name
    @TypeConverter fun aTipo(s: String): Tipo = Tipo.valueOf(s)
}

@Database(entities = [Habito::class, Registro::class], version = 1, exportSchema = true)
@TypeConverters(Conversores::class)
abstract class BaseDatos : RoomDatabase() {
    abstract fun habitos(): HabitoDao

    companion object {
        fun crear(context: Context): BaseDatos =
            Room.databaseBuilder(context, BaseDatos::class.java, "shabit.db").build()
    }
}
