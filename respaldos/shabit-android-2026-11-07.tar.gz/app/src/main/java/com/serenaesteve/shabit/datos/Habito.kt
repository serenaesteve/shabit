package com.serenaesteve.shabit.datos

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Un hábito tiene un color de disco, un objetivo semanal (cuántos días de cada
 * semana quieres cumplirlo) y una meta total de discos.
 */
@Entity(tableName = "habitos")
data class Habito(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val nombre: String,
    /** Índice en la paleta de discos ([com.serenaesteve.shabit.iu.tema.Discos]). */
    val color: Int,
    /** Días por semana que quieres cumplirlo, de 1 a 7. */
    val objetivoSemanal: Int,
    /** Discos totales que completan la meta (21, 30, 66…). */
    val meta: Int,
    /** Día de creación como LocalDate.toEpochDay(). */
    val creado: Long,
    /** Hora del recordatorio en minutos desde las 00:00, o null si no avisa. */
    val recordatorio: Int? = null,
    /** Si no es null, el día se marca solo al llegar a estos pasos. */
    val pasos: Int? = null,
    val archivado: Boolean = false,
    val orden: Int = 0,
)

/** Qué pasó un día con un hábito. Los días sin registro son días no cumplidos. */
enum class Tipo { HECHO, DESCANSO }

@Entity(
    tableName = "registros",
    primaryKeys = ["habitoId", "dia"],
    foreignKeys = [
        ForeignKey(
            entity = Habito::class,
            parentColumns = ["id"],
            childColumns = ["habitoId"],
            onDelete = ForeignKey.CASCADE,
        ),
    ],
    indices = [Index("dia")],
)
data class Registro(
    val habitoId: Long,
    /** LocalDate.toEpochDay() del día. */
    val dia: Long,
    val tipo: Tipo,
)
