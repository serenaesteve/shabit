package com.serenaesteve.shabit.iu.pantallas

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.serenaesteve.shabit.datos.Tipo
import com.serenaesteve.shabit.dominio.Ficha
import com.serenaesteve.shabit.iu.EstadoShabit
import com.serenaesteve.shabit.iu.discos
import com.serenaesteve.shabit.iu.fechaLarga
import com.serenaesteve.shabit.iu.gimnasio.Boton
import com.serenaesteve.shabit.iu.gimnasio.DiscoResumen
import com.serenaesteve.shabit.iu.gimnasio.HuecoDisco
import com.serenaesteve.shabit.iu.gimnasio.Separador
import com.serenaesteve.shabit.iu.gimnasio.discoDeFrente
import com.serenaesteve.shabit.iu.inicial
import com.serenaesteve.shabit.iu.mesCorto
import com.serenaesteve.shabit.iu.miles
import com.serenaesteve.shabit.iu.nombreDia
import com.serenaesteve.shabit.iu.racha
import com.serenaesteve.shabit.iu.tema.Letra
import com.serenaesteve.shabit.iu.tema.LocalSuelo
import com.serenaesteve.shabit.iu.tema.colorDisco
import com.serenaesteve.shabit.iu.tipo
import com.serenaesteve.shabit.pasos.FuentePasos
import java.time.LocalDate

/** Sugerencias para empezar con un toque. El segundo valor son los pasos, si los lleva. */
val sugerencias = listOf(
    "Caminar" to 8000, "Leer 20 minutos" to null, "Beber 2 litros de agua" to null,
    "Estirar" to null, "Meditar" to null, "Sin pantallas al dormir" to null,
)

@Composable
fun Hoy(
    estado: EstadoShabit,
    alternar: (Long, LocalDate, Tipo) -> Unit,
    descansoHoy: () -> Unit,
    abrirFicha: (Long) -> Unit,
    nuevo: (String?, Int?) -> Unit,
    ajustes: () -> Unit,
    pedirPermisoPasos: () -> Unit,
    relleno: PaddingValues,
) {
    val s = LocalSuelo.current
    val hoy = estado.hoy
    val hechosHoy = estado.fichas.count { estado.tipoHoy(it) == Tipo.HECHO }
    val pendientes = estado.fichas.count { estado.tipoHoy(it) == null }
    val vibra = LocalHapticFeedback.current

    LazyColumn(contentPadding = relleno, modifier = Modifier.fillMaxWidth()) {
        item {
            Row(
                Modifier.fillMaxWidth().padding(start = 20.dp, end = 12.dp, top = 8.dp),
                verticalAlignment = Alignment.Top,
            ) {
                Column(Modifier.weight(1f).padding(top = 12.dp)) {
                    Text(
                        "${nombreDia(hoy)} ${hoy.dayOfMonth} ${mesCorto(hoy)}".uppercase(),
                        style = Letra.etiqueta, color = s.tintaSuave,
                    )
                    Text("HOY", style = Letra.portada, color = s.tinta, modifier = Modifier.semantics { heading() })
                    Spacer(Modifier.height(4.dp))
                    Text(
                        when {
                            estado.fichas.isEmpty() -> "Barra vacía. Elige tu primer hábito."
                            hechosHoy == estado.fichas.size -> "Barra cargada. Día completo."
                            pendientes == 0 -> "Hoy toca descanso."
                            hechosHoy == 0 -> "Aún no has cargado ningún disco hoy."
                            else -> "Te quedan $pendientes por cargar."
                        },
                        style = Letra.cuerpo, color = s.tintaSuave,
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        "AJUSTES", style = Letra.etiqueta, color = s.tintaSuave,
                        modifier = Modifier.clickable(onClick = ajustes).padding(8.dp),
                    )
                    if (estado.fichas.isNotEmpty()) {
                        DiscoResumen(
                            estado.fichas.map { colorDisco(it.habito.color) to estado.tipoHoy(it) },
                            Modifier.size(118.dp),
                        ) {
                            Text(
                                "$hechosHoy/${estado.fichas.size}", style = Letra.dato,
                                color = androidx.compose.ui.graphics.Color(0xFFF1F0EC),
                                modifier = Modifier.padding(top = 62.dp),
                            )
                        }
                    }
                }
            }
            if (estado.hayPasos) BloquePasos(estado, pedirPermisoPasos)
            Spacer(Modifier.height(14.dp))
            Separador(Modifier.fillMaxWidth().height(2.dp).padding(horizontal = 20.dp))
        }

        if (!estado.cargando && estado.fichas.isEmpty()) {
            item { Vacio(nuevo) }
        }

        items(estado.fichas, key = { it.habito.id }) { ficha ->
            FilaHabito(
                ficha, hoy, estado.pasos.hoy,
                alternar = { dia, t ->
                    if (estado.ajustes.vibracion) vibra.performHapticFeedback(HapticFeedbackType.LongPress)
                    alternar(ficha.habito.id, dia, t)
                },
                abrir = { abrirFicha(ficha.habito.id) },
            )
        }

        if (estado.fichas.isNotEmpty()) {
            item {
                Column(Modifier.padding(horizontal = 20.dp, vertical = 18.dp)) {
                    Text(
                        "Toca un hueco para cargar el disco. Mantenlo pulsado para marcar descanso: no cuenta, pero tampoco rompe la racha.",
                        style = Letra.nota, color = s.tintaSuave,
                    )
                    Spacer(Modifier.height(16.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Boton("+ Hábito", { nuevo(null, null) }, Modifier.weight(1f))
                        Boton(
                            if (pendientes > 0) "Hoy descanso" else "Quitar descanso",
                            descansoHoy, Modifier.weight(1f),
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun BloquePasos(estado: EstadoShabit, pedirPermiso: () -> Unit) {
    val s = LocalSuelo.current
    val p = estado.pasos
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 20.dp).padding(top = 14.dp),
        verticalAlignment = Alignment.Bottom,
    ) {
        when {
            p.fuente == FuentePasos.NINGUNA -> Text(
                "Este móvil no tiene sensor para contar pasos.", style = Letra.nota, color = s.tintaSuave,
            )
            !p.permiso -> Boton("Permitir contar pasos", pedirPermiso, Modifier.fillMaxWidth())
            else -> {
                Text(miles(p.hoy), style = Letra.cifra, color = s.tinta)
                Spacer(Modifier.width(8.dp))
                Column {
                    Text("PASOS HOY", style = Letra.etiqueta, color = s.tintaSuave)
                    if (p.fuente == FuentePasos.ACELEROMETRO) {
                        Text("Se cuentan con la app abierta", style = Letra.nota, color = s.tintaSuave)
                    }
                }
            }
        }
    }
}

@Composable
private fun FilaHabito(ficha: Ficha, hoy: LocalDate, pasosHoy: Int, alternar: (LocalDate, Tipo) -> Unit, abrir: () -> Unit) {
    val s = LocalSuelo.current
    val color = colorDisco(ficha.habito.color)
    val h = ficha.habito
    Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp).padding(top = 18.dp)) {
        Row(
            Modifier.fillMaxWidth().clickable(onClick = abrir).padding(vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Canvas(Modifier.size(22.dp)) { discoDeFrente(center, size.minDimension / 2, color, Tipo.HECHO, s) }
            Spacer(Modifier.width(10.dp))
            Text(h.nombre.uppercase(), style = Letra.nombre, color = s.tinta, modifier = Modifier.weight(1f))
            Text(
                "${ficha.estaSemana}/${ficha.objetivoSemana ?: h.objetivoSemanal} SEM",
                style = Letra.dato,
                color = if (ficha.semanaCumplida) color else s.tintaSuave,
            )
        }
        Spacer(Modifier.height(4.dp))
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Bottom,
        ) {
            for (atras in 6 downTo 0) {
                val dia = hoy.minusDays(atras.toLong())
                val esHoy = atras == 0
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    HuecoDisco(
                        tipo = tipo(ficha, dia),
                        color = color,
                        descripcion = "${h.nombre}, ${fechaLarga(dia)}",
                        alto = if (esHoy) 66.dp else 54.dp,
                        destacado = esHoy,
                        alTocar = { alternar(dia, Tipo.HECHO) },
                        alMantener = { alternar(dia, Tipo.DESCANSO) },
                    )
                    Text(
                        if (esHoy) "HOY" else inicial(dia.dayOfWeek),
                        style = Letra.etiqueta,
                        color = if (esHoy) s.tinta else s.tintaSuave,
                        textAlign = TextAlign.Center,
                    )
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(
            buildString {
                if (ficha.racha == 0) append("SIN RACHA AÚN")
                else append("RACHA ").append(racha(ficha.racha, ficha.rachaEnDias).uppercase())
                append("  ·  ").append(ficha.total).append("/").append(h.meta).append(" DISCOS")
                h.pasos?.let { append("  ·  ").append(miles(pasosHoy)).append("/").append(miles(it)).append(" PASOS") }
            },
            style = Letra.etiqueta, color = s.tintaSuave,
        )
        Spacer(Modifier.height(14.dp))
        Separador(Modifier.fillMaxWidth().height(2.dp))
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun Vacio(nuevo: (String?, Int?) -> Unit) {
    val s = LocalSuelo.current
    Column(Modifier.fillMaxWidth().padding(20.dp)) {
        Spacer(Modifier.height(16.dp))
        Text("CARGA TU PRIMER HÁBITO", style = Letra.titulo, color = s.tinta)
        Spacer(Modifier.height(8.dp))
        Text(
            "Cada día que lo cumplas cargarás un disco en su barra. Las semanas se apilan y se ve cuánto has levantado.",
            style = Letra.cuerpo, color = s.tintaSuave,
        )
        Spacer(Modifier.height(20.dp))
        Text("PARA EMPEZAR", style = Letra.etiqueta, color = s.tintaSuave)
        Spacer(Modifier.height(8.dp))
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            sugerencias.forEach { (texto, pasos) ->
                Boton(if (pasos != null) "$texto · ${miles(pasos)} pasos" else texto, { nuevo(texto, pasos) })
            }
        }
        Spacer(Modifier.height(16.dp))
        Boton("+ Uno a mi manera", { nuevo(null, null) }, Modifier.fillMaxWidth(), relleno = true)
    }
}

