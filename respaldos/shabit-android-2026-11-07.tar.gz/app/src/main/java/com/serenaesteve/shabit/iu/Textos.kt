package com.serenaesteve.shabit.iu

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.format.TextStyle
import java.util.Locale

val es: Locale = Locale.forLanguageTag("es-ES")

fun inicial(d: DayOfWeek): String = when (d) {
    DayOfWeek.MONDAY -> "L"; DayOfWeek.TUESDAY -> "M"; DayOfWeek.WEDNESDAY -> "X"
    DayOfWeek.THURSDAY -> "J"; DayOfWeek.FRIDAY -> "V"; DayOfWeek.SATURDAY -> "S"
    DayOfWeek.SUNDAY -> "D"
}

fun diasDeSemana(primerDia: DayOfWeek): List<DayOfWeek> = (0L until 7L).map { primerDia.plus(it) }

fun nombreDia(f: LocalDate): String = f.dayOfWeek.getDisplayName(TextStyle.FULL, es)
fun mesCorto(f: LocalDate): String = f.month.getDisplayName(TextStyle.SHORT, es).trimEnd('.')
fun mesLargo(f: LocalDate): String = f.month.getDisplayName(TextStyle.FULL_STANDALONE, es)

fun fechaLarga(f: LocalDate): String = "${nombreDia(f)} ${f.dayOfMonth} de ${mesLargo(f)}"

fun hora(minutos: Int): String = "%02d:%02d".format(minutos / 60, minutos % 60)

fun racha(n: Int, enDias: Boolean): String = when {
    enDias -> if (n == 1) "1 día" else "$n días"
    else -> if (n == 1) "1 semana" else "$n semanas"
}

fun objetivoTexto(n: Int): String = when (n) {
    7 -> "todos los días"
    1 -> "1 día por semana"
    else -> "$n días por semana"
}

/** 6240 → "6.240", como se escriben los miles en España. */
fun miles(n: Int): String = "%,d".format(es, n)

fun discos(n: Int): String = if (n == 1) "1 disco" else "$n discos"
