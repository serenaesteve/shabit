package com.serenaesteve.shabit.recordatorios

import android.content.Context
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.workDataOf
import com.serenaesteve.shabit.datos.Habito
import java.time.Duration
import java.time.LocalDateTime
import java.time.LocalTime
import java.util.concurrent.TimeUnit

/**
 * Programa un aviso diario por hábito con WorkManager. WorkManager sobrevive a
 * reinicios del móvil sin necesidad de un receptor de BOOT_COMPLETED.
 */
object Recordatorios {
    private fun nombre(id: Long) = "recordatorio-$id"

    fun programar(context: Context, habito: Habito) {
        val minutos = habito.recordatorio
        if (minutos == null || habito.archivado) {
            cancelar(context, habito.id); return
        }
        val pedido = PeriodicWorkRequestBuilder<RecordatorioWorker>(1, TimeUnit.DAYS)
            .setInitialDelay(retrasoHasta(minutos).toMillis(), TimeUnit.MILLISECONDS)
            .setInputData(workDataOf(RecordatorioWorker.HABITO to habito.id))
            .addTag("recordatorio")
            .build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            nombre(habito.id), ExistingPeriodicWorkPolicy.CANCEL_AND_REENQUEUE, pedido,
        )
    }

    fun cancelar(context: Context, habitoId: Long) {
        WorkManager.getInstance(context).cancelUniqueWork(nombre(habitoId))
    }

    /** Tiempo que falta hasta la próxima vez que el reloj marque esa hora. */
    fun retrasoHasta(minutos: Int, ahora: LocalDateTime = LocalDateTime.now()): Duration {
        var cuando = ahora.toLocalDate().atTime(LocalTime.of(minutos / 60, minutos % 60))
        if (!cuando.isAfter(ahora)) cuando = cuando.plusDays(1)
        return Duration.between(ahora, cuando)
    }
}
