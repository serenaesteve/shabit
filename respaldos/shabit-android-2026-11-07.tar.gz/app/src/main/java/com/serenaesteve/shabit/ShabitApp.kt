package com.serenaesteve.shabit

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import com.serenaesteve.shabit.datos.BaseDatos
import com.serenaesteve.shabit.datos.Preferencias
import com.serenaesteve.shabit.datos.Repositorio
import com.serenaesteve.shabit.pasos.PasosWorker
import com.serenaesteve.shabit.pasos.Podometro
import com.serenaesteve.shabit.widget.WidgetHoy

/** Contenedor de dependencias de la app. */
class ShabitApp : Application() {
    val baseDatos by lazy { BaseDatos.crear(this) }
    val repositorio by lazy { Repositorio(baseDatos.habitos()) { WidgetHoy.actualizar(this) } }
    val preferencias by lazy { Preferencias(this) }
    val podometro by lazy { Podometro(this, repositorio) }

    override fun onCreate() {
        super.onCreate()
        val canal = NotificationChannel(
            CANAL_RECORDATORIOS,
            getString(R.string.canal_recordatorios),
            NotificationManager.IMPORTANCE_DEFAULT,
        ).apply { description = getString(R.string.canal_recordatorios_desc) }
        getSystemService(NotificationManager::class.java).createNotificationChannel(canal)
        PasosWorker.programar(this)
    }

    companion object {
        const val CANAL_RECORDATORIOS = "recordatorios"
    }
}
