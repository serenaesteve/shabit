package com.serenaesteve.shabit.iu.pantallas

import android.Manifest
import android.app.TimePickerDialog
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.serenaesteve.shabit.datos.Habito
import com.serenaesteve.shabit.datos.Tipo
import com.serenaesteve.shabit.iu.EstadoPasosIu
import com.serenaesteve.shabit.iu.gimnasio.Boton
import com.serenaesteve.shabit.iu.gimnasio.HuecoDisco
import com.serenaesteve.shabit.iu.gimnasio.Separador
import com.serenaesteve.shabit.iu.gimnasio.discoDeFrente
import com.serenaesteve.shabit.iu.hora
import com.serenaesteve.shabit.iu.miles
import com.serenaesteve.shabit.iu.objetivoTexto
import com.serenaesteve.shabit.iu.tema.Discos
import com.serenaesteve.shabit.iu.tema.Letra
import com.serenaesteve.shabit.iu.tema.LocalSuelo
import com.serenaesteve.shabit.iu.tema.colorDisco
import com.serenaesteve.shabit.pasos.FuentePasos
import java.time.LocalDate

val metas = listOf(21, 30, 66, 100, 365)
val objetivosPasos = listOf(4000, 6000, 8000, 10000, 12000)

/** Plan de un hábito: nombre, color, objetivo semanal, meta, pasos y aviso. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun Plan(
    existente: Habito?,
    nombreInicial: String?,
    pasosIniciales: Int?,
    hoy: LocalDate,
    pasos: EstadoPasosIu,
    guardar: (Habito) -> Unit,
    archivar: (Habito) -> Unit,
    borrar: (Habito) -> Unit,
    permisoPasosCambiado: () -> Unit,
    volver: () -> Unit,
    relleno: PaddingValues,
) {
    val s = LocalSuelo.current
    val contexto = LocalContext.current
    var nombre by rememberSaveable { mutableStateOf(existente?.nombre ?: nombreInicial.orEmpty()) }
    var color by rememberSaveable { mutableIntStateOf(existente?.color ?: (0 until Discos.size).random()) }
    var objetivo by rememberSaveable { mutableIntStateOf(existente?.objetivoSemanal ?: if (pasosIniciales != null) 7 else 5) }
    var meta by rememberSaveable { mutableIntStateOf(existente?.meta ?: 66) }
    var aviso by rememberSaveable { mutableStateOf(existente?.recordatorio) }
    var objetivoPasos by rememberSaveable { mutableStateOf(existente?.pasos ?: pasosIniciales) }
    var confirmarBorrado by rememberSaveable { mutableStateOf(false) }
    var sinPermisoAviso by rememberSaveable { mutableStateOf(false) }
    var sinPermisoPasos by rememberSaveable { mutableStateOf(false) }
    val c = colorDisco(color)

    val pedirAvisos = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { sinPermisoAviso = !it }
    val pedirActividad = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        sinPermisoPasos = !it
        permisoPasosCambiado()
    }

    fun elegirPasos(n: Int?) {
        objetivoPasos = n
        if (n != null && pasos.fuente == FuentePasos.CONTADOR && Build.VERSION.SDK_INT >= 29 &&
            ContextCompat.checkSelfPermission(contexto, Manifest.permission.ACTIVITY_RECOGNITION) != PackageManager.PERMISSION_GRANTED
        ) pedirActividad.launch(Manifest.permission.ACTIVITY_RECOGNITION)
    }

    fun elegirHora() {
        val actual = aviso ?: (20 * 60 + 30)
        TimePickerDialog(contexto, { _, h, m ->
            aviso = h * 60 + m
            if (Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(contexto, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) pedirAvisos.launch(Manifest.permission.POST_NOTIFICATIONS)
        }, actual / 60, actual % 60, true).show()
    }

    Column(Modifier.verticalScroll(rememberScrollState()).padding(relleno).imePadding().padding(horizontal = 20.dp)) {
        Text(
            "‹ VOLVER", style = Letra.etiqueta, color = s.tintaSuave,
            modifier = Modifier.clickable(onClick = volver).padding(vertical = 12.dp),
        )
        Text(if (existente == null) "PLAN NUEVO" else "EDITAR PLAN", style = Letra.etiqueta, color = s.tintaSuave)
        Spacer(Modifier.height(4.dp))
        BasicTextField(
            value = nombre,
            onValueChange = { if (it.length <= 40) nombre = it },
            textStyle = Letra.titulo.copy(color = s.tinta),
            cursorBrush = SolidColor(c),
            singleLine = true,
            keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences, imeAction = ImeAction.Done),
            modifier = Modifier.fillMaxWidth().semantics { contentDescription = "Nombre del hábito" },
            decorationBox = { campo ->
                Column {
                    Box {
                        if (nombre.isEmpty()) Text("¿Qué vas a entrenar?", style = Letra.titulo, color = s.aceroOscuro)
                        campo()
                    }
                    Spacer(Modifier.height(6.dp))
                    Canvas(Modifier.fillMaxWidth().height(4.dp)) {
                        drawRect(if (nombre.isBlank()) s.linea else c)
                    }
                }
            },
        )

        Seccion("COLOR DEL DISCO · ${Discos[color].nombre.uppercase()}")
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Discos.forEachIndexed { i, d ->
                Canvas(
                    Modifier
                        .size(48.dp)
                        .semantics { contentDescription = "Disco ${d.nombre}"; selected = i == color }
                        .clickable(role = Role.RadioButton) { color = i },
                ) {
                    discoDeFrente(center, size.minDimension * 0.4f, d.color, Tipo.HECHO, s)
                    if (i == color) drawCircle(s.tinta, size.minDimension * 0.48f, center, style = Stroke(2.dp.toPx()))
                }
            }
        }

        Seccion("OBJETIVO · ${objetivoTexto(objetivo).uppercase()}")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            for (n in 1..7) {
                HuecoDisco(
                    tipo = if (n <= objetivo) Tipo.HECHO else null, color = c,
                    descripcion = objetivoTexto(n), alto = 52.dp, destacado = n == objetivo,
                    alTocar = { objetivo = n }, alMantener = { objetivo = n },
                )
            }
        }
        Spacer(Modifier.height(6.dp))
        Text("Cuántos días de cada semana quieres cumplirlo. Los días de descanso rebajan el objetivo de esa semana.", style = Letra.nota, color = s.tintaSuave)

        Seccion("META · $meta DISCOS")
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            metas.forEach { m -> Boton("$m", { meta = m }, relleno = m == meta, color = if (m == meta) c else null) }
        }

        Seccion("PASOS")
        if (pasos.fuente == FuentePasos.NINGUNA) {
            Text("Este móvil no tiene sensor para contar pasos.", style = Letra.nota, color = s.tintaSuave)
        } else {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Boton("No", { elegirPasos(null) }, relleno = objetivoPasos == null, color = if (objetivoPasos == null) c else null)
                objetivosPasos.forEach { n ->
                    Boton(miles(n), { elegirPasos(n) }, relleno = objetivoPasos == n, color = if (objetivoPasos == n) c else null)
                }
            }
            Spacer(Modifier.height(6.dp))
            Text(
                when {
                    objetivoPasos == null -> "Si eliges un número de pasos, el día se marca solo al llegar."
                    pasos.fuente == FuentePasos.ACELEROMETRO ->
                        "Tu móvil no tiene contador de pasos: se cuentan con el acelerómetro mientras la app está abierta."
                    else -> "El día se marca solo al llegar a ${miles(objetivoPasos!!)} pasos, aunque no abras la app."
                },
                style = Letra.nota, color = s.tintaSuave,
            )
            if (sinPermisoPasos && objetivoPasos != null) {
                Text(
                    "Sin el permiso de actividad física no se pueden contar los pasos. Puedes darlo en los ajustes de Android.",
                    style = Letra.nota, color = colorDisco(0),
                )
            }
        }

        Seccion("AVISO")
        Row(verticalAlignment = Alignment.CenterVertically) {
            Boton(aviso?.let { "Avisarme a las ${hora(it)}" } ?: "Sin aviso", ::elegirHora, Modifier.weight(1f))
            if (aviso != null) {
                Text("QUITAR", style = Letra.etiqueta, color = s.tintaSuave, modifier = Modifier.clickable { aviso = null }.padding(12.dp))
            }
        }
        if (sinPermisoAviso && aviso != null) {
            Text(
                "Sin permiso de notificaciones no podrás recibir el aviso. Puedes darlo en los ajustes de Android.",
                style = Letra.nota, color = colorDisco(0),
            )
        }

        Spacer(Modifier.height(28.dp))
        Boton(
            if (existente == null) "Crear hábito" else "Guardar plan",
            {
                if (nombre.isNotBlank()) guardar(
                    (existente ?: Habito(nombre = "", color = 0, objetivoSemanal = 5, meta = 66, creado = hoy.toEpochDay()))
                        .copy(
                            nombre = nombre.trim(), color = color, objetivoSemanal = objetivo, meta = meta,
                            recordatorio = aviso, pasos = objetivoPasos,
                        ),
                )
            },
            Modifier.fillMaxWidth(), relleno = nombre.isNotBlank(),
        )
        if (existente != null) {
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Boton("Guardar aparte", { archivar(existente) }, Modifier.weight(1f))
                Boton("Borrar", { confirmarBorrado = true }, Modifier.weight(1f), color = colorDisco(0))
            }
            Spacer(Modifier.height(6.dp))
            Text("«Guardar aparte» lo quita de Hoy sin borrar su historial. «Borrar» lo elimina todo.", style = Letra.nota, color = s.tintaSuave)
        }
        Spacer(Modifier.height(32.dp))
    }

    if (confirmarBorrado && existente != null) {
        AlertDialog(
            onDismissRequest = { confirmarBorrado = false },
            title = { Text("¿Borrar «${existente.nombre}»?", style = Letra.nombre) },
            text = { Text("Se borrarán el hábito y todo su historial. No se puede deshacer.", style = Letra.cuerpo) },
            confirmButton = {
                TextButton(onClick = { confirmarBorrado = false; borrar(existente) }) {
                    Text("BORRAR", style = Letra.dato, color = colorDisco(0))
                }
            },
            dismissButton = {
                TextButton(onClick = { confirmarBorrado = false }) { Text("CANCELAR", style = Letra.dato, color = s.tinta) }
            },
            containerColor = s.fondo,
        )
    }
}

@Composable
private fun Seccion(texto: String) {
    val s = LocalSuelo.current
    Spacer(Modifier.height(24.dp))
    Text(texto, style = Letra.etiqueta, color = s.tintaSuave)
    Spacer(Modifier.height(4.dp))
    Separador(Modifier.fillMaxWidth().height(1.dp))
    Spacer(Modifier.height(10.dp))
}
