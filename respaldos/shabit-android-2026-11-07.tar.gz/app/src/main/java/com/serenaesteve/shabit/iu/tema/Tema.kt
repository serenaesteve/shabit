package com.serenaesteve.shabit.iu.tema

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.serenaesteve.shabit.R
import com.serenaesteve.shabit.datos.Tema

/** Colores del suelo del gimnasio: goma negra con motas o magnesio claro. */
@Immutable
data class Suelo(
    val fondo: Color,
    val motas: List<Color>,
    val franja: Color,
    val tinta: Color,
    val tintaSuave: Color,
    val acero: Color,
    val aceroOscuro: Color,
    val linea: Color,
    val oscuro: Boolean,
)

val Goma = Suelo(
    fondo = Color(0xFF151619),
    motas = listOf(Color(0xFF23252A), Color(0xFF2C2F35), Color(0xFF383B42), Color(0xFF26303A)),
    franja = Color(0xFF0E0F11),
    tinta = Color(0xFFF1F0EC),
    tintaSuave = Color(0xFF8E939B),
    acero = Color(0xFFB4B9C0),
    aceroOscuro = Color(0xFF5B6068),
    linea = Color(0xFF2A2D33),
    oscuro = true,
)

val Magnesio = Suelo(
    fondo = Color(0xFFEAE9E5),
    motas = listOf(Color(0xFFDCDAD4), Color(0xFFD0CEC7), Color(0xFFF5F4F1), Color(0xFFC9CCD0)),
    franja = Color(0xFF1B1C20),
    tinta = Color(0xFF15161A),
    tintaSuave = Color(0xFF5C6068),
    acero = Color(0xFF7C8189),
    aceroOscuro = Color(0xFF4A4E55),
    linea = Color(0xFFD3D1CB),
    oscuro = false,
)

val LocalSuelo = staticCompositionLocalOf { Goma }

/** Colores de disco disponibles. El índice se guarda en la base de datos. */
data class ColorDisco(val nombre: String, val color: Color)

val Discos = listOf(
    ColorDisco("Rojo", Color(0xFFD7262E)),
    ColorDisco("Azul", Color(0xFF1F5FBF)),
    ColorDisco("Amarillo", Color(0xFFF2B705)),
    ColorDisco("Verde", Color(0xFF2E8B3E)),
    ColorDisco("Blanco", Color(0xFFE6E6E1)),
    ColorDisco("Naranja", Color(0xFFEE6A1F)),
    ColorDisco("Morado", Color(0xFF7446AE)),
    ColorDisco("Turquesa", Color(0xFF13A3A3)),
    ColorDisco("Rosa", Color(0xFFE0508A)),
    ColorDisco("Grafito", Color(0xFF5F646C)),
)

fun colorDisco(indice: Int): Color = Discos[indice.mod(Discos.size)].color

/** Texto legible sobre un disco: oscuro sobre amarillo o blanco, claro sobre el resto. */
fun tintaSobre(fondo: Color): Color = if (fondo.luminance() > 0.45f) Color(0xFF15161A) else Color(0xFFF7F7F4)

private val Condensada = FontFamily(
    Font(R.font.barlowcondensed_medium, FontWeight.Medium),
    Font(R.font.barlowcondensed_semibold, FontWeight.SemiBold),
    Font(R.font.barlowcondensed_bold, FontWeight.Bold),
)
private val Barlow = FontFamily(
    Font(R.font.barlow_regular, FontWeight.Normal),
    Font(R.font.barlow_medium, FontWeight.Medium),
)

object Letra {
    val portada = TextStyle(fontFamily = Condensada, fontWeight = FontWeight.Bold, fontSize = 64.sp, lineHeight = 60.sp, letterSpacing = (-0.5).sp)
    val titulo = TextStyle(fontFamily = Condensada, fontWeight = FontWeight.Bold, fontSize = 34.sp, lineHeight = 36.sp)
    val nombre = TextStyle(fontFamily = Condensada, fontWeight = FontWeight.SemiBold, fontSize = 24.sp, lineHeight = 26.sp)
    val cuerpo = TextStyle(fontFamily = Barlow, fontSize = 16.sp, lineHeight = 22.sp)
    val nota = TextStyle(fontFamily = Barlow, fontSize = 14.sp, lineHeight = 19.sp)
    val etiqueta = TextStyle(fontFamily = Condensada, fontWeight = FontWeight.Medium, fontSize = 14.sp, lineHeight = 16.sp, letterSpacing = 1.2.sp)
    val dato = TextStyle(fontFamily = Condensada, fontWeight = FontWeight.SemiBold, fontSize = 18.sp, lineHeight = 20.sp, letterSpacing = 0.4.sp)
    val cifra = TextStyle(fontFamily = Condensada, fontWeight = FontWeight.Bold, fontSize = 40.sp, lineHeight = 40.sp)
}

@Composable
fun ShabitTema(tema: Tema, contenido: @Composable () -> Unit) {
    val oscuro = when (tema) {
        Tema.SISTEMA -> isSystemInDarkTheme()
        Tema.MAGNESIO -> false
        Tema.GOMA -> true
    }
    val s = if (oscuro) Goma else Magnesio
    val esquema = if (oscuro) darkColorScheme(
        primary = s.tinta, onPrimary = s.fondo, surface = s.fondo, onSurface = s.tinta,
        surfaceContainerHigh = s.linea, background = s.fondo, onBackground = s.tinta,
        outline = s.aceroOscuro, onSurfaceVariant = s.tintaSuave,
    ) else lightColorScheme(
        primary = s.tinta, onPrimary = s.fondo, surface = s.fondo, onSurface = s.tinta,
        surfaceContainerHigh = s.fondo, background = s.fondo, onBackground = s.tinta,
        outline = s.aceroOscuro, onSurfaceVariant = s.tintaSuave,
    )
    CompositionLocalProvider(LocalSuelo provides s) {
        MaterialTheme(colorScheme = esquema, content = contenido)
    }
}
