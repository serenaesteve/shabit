package com.serenaesteve.shabit.recordatorios

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationManagerCompat
import com.serenaesteve.shabit.ShabitApp
import com.serenaesteve.shabit.datos.Tipo
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/** Botón "Hecho" de la notificación: carga el disco del día sin abrir la app. */
class HechoReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getLongExtra(HABITO, -1)
        val dia = intent.getLongExtra(DIA, -1)
        if (id < 0 || dia < 0) return
        val pendiente = goAsync()
        val repo = (context.applicationContext as ShabitApp).repositorio
        CoroutineScope(Dispatchers.IO).launch {
            try {
                repo.marcar(id, dia, Tipo.HECHO)
                NotificationManagerCompat.from(context).cancel(id.toInt())
            } finally {
                pendiente.finish()
            }
        }
    }

    companion object {
        const val HABITO = "habito"
        const val DIA = "dia"
    }
}
