package com.serenaesteve.shabit.iu.pantallas

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.serenaesteve.shabit.datos.Tipo
import com.serenaesteve.shabit.dominio.Ficha
import com.serenaesteve.shabit.iu.EstadoShabit
import com.serenaesteve.shabit.iu.diasDeSemana
import com.serenaesteve.shabit.iu.fechaLarga
import com.serenaesteve.shabit.iu.gimnasio.Boton
import com.serenaesteve.shabit.iu.gimnasio.Separador
import com.serenaesteve.shabit.iu.gimnasio.discoDeFrente
import com.serenaesteve.shabit.iu.hora
import com.serenaesteve.shabit.iu.inicial
import com.serenaesteve.shabit.iu.mesLargo
import com.serenaesteve.shabit.iu.miles
import com.serenaesteve.shabit.iu.objetivoTexto
import com.serenaesteve.shabit.iu.racha
import com.serenaesteve.shabit.iu.tema.Discos
import com.serenaesteve.shabit.iu.tema.Letra
import com.serenaesteve.shabit.iu.tema.LocalSuelo
import com.serenaesteve.shabit.iu.tema.colorDisco
import com.serenaesteve.shabit.iu.tipo
import java.time.LocalDate
import java.time.YearMonth
import kotlin.math.roundToInt

@Composable
fun Detalle(
    estado: EstadoShabit,
    id: Long,
    alternar: (Long, LocalDate, Tipo) -> Unit,
    editar: () -> Unit,
    volver: () -> Unit,
    relleno: PaddingValues,
) {
    val s = LocalSuelo.current
    val ficha = estado.ficha(id) ?: return
    val h = ficha.habito
    val color = colorDisco(h.color)
    val vibra = LocalHapticFeedback.current
    var mesN by rememberSaveable { mutableIntStateOf(YearMonth.from(estado.hoy).let { it.year * 12 + it.monthValue - 1 }) }
    val mes = YearMonth.of(mesN / 12, mesN % 12 + 1)

    Column(Modifier.verticalScroll(rememberScrollState()).padding(relleno).padding(horizontal = 20.dp)) {
        Text(
            "‹ VOLVER", style = Letra.etiqueta, color = s.tintaSuave,
            modifier = Modifier.clickable(onClick = volver).padding(vertical = 12.dp),
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            Canvas(Modifier.size(26.dp)) { discoDeFrente(center, size.minDimension / 2, color, Tipo.HECHO, s) }
            Spacer(Modifier.width(10.dp))
            Text("DISCO ${Discos[h.color.mod(Discos.size)].nombre.uppercase()}", style = Letra.etiqueta, color = s.tintaSuave)
        }
        Text(h.nombre.uppercase(), style = Letra.portada.copy(fontSize = 48.sp, lineHeight = 48.sp), color = s.tinta, modifier = Modifier.semantics { heading() })
        Spacer(Modifier.height(6.dp))
        Text(
            buildString {
                append(objetivoTexto(h.objetivoSemanal).replaceFirstChar { it.uppercase() })
                append(" · meta de ").append(h.meta).append(" discos")
                h.pasos?.let { append(" · se marca solo a los ").append(miles(it)).append(" pasos") }
                h.recordatorio?.let { append(" · aviso a las ").append(hora(it)) }
            },
            style = Letra.cuerpo, color = s.tintaSuave,
        )

        Spacer(Modifier.height(18.dp))
        Fila("ESTA SEMANA", "${ficha.estaSemana} de ${ficha.objetivoSemana ?: h.objetivoSemanal}${if (ficha.semanaCumplida) " ✓" else ""}")
        Fila("RACHA ACTUAL", racha(ficha.racha, ficha.rachaEnDias))
        Fila("RÉCORD", racha(ficha.mejorRacha, ficha.rachaEnDias))
        Fila("CONSTANCIA · 12 SEMANAS", ficha.constancia?.let { "${(it * 100).roundToInt()} %" } ?: "aún sin semanas")
        Fila("DÍAS DE DESCANSO", "${ficha.descansos.size}")
        Spacer(Modifier.height(14.dp))
        Meta(ficha, color)

        Spacer(Modifier.height(24.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("‹", style = Letra.titulo, color = s.tinta, modifier = Modifier.clickable { mesN-- }.padding(horizontal = 14.dp))
            Text(
                "${mesLargo(mes.atDay(1))} ${mes.year}".uppercase(),
                style = Letra.nombre, color = s.tinta, textAlign = TextAlign.Center, modifier = Modifier.weight(1f),
            )
            val futuro = !mes.isBefore(YearMonth.from(estado.hoy))
            Text(
                "›", style = Letra.titulo, color = if (futuro) s.linea else s.tinta,
                modifier = Modifier.clickable(enabled = !futuro) { mesN++ }.padding(horizontal = 14.dp),
            )
        }
        Spacer(Modifier.height(8.dp))
        Calendario(mes, estado, ficha, color) { dia, t ->
            if (estado.ajustes.vibracion) vibra.performHapticFeedback(HapticFeedbackType.LongPress)
            alternar(id, dia, t)
        }
        Spacer(Modifier.height(8.dp))
        Text(
            "Toca un día para marcarlo como hecho. Mantenlo pulsado para descanso.",
            style = Letra.nota, color = s.tintaSuave,
        )
        Spacer(Modifier.height(22.dp))
        Boton("Editar plan", editar, Modifier.fillMaxWidth())
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun Fila(etiqueta: String, valor: String) {
    val s = LocalSuelo.current
    Column {
        Row(Modifier.fillMaxWidth().padding(vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(etiqueta, style = Letra.etiqueta, color = s.tintaSuave, modifier = Modifier.weight(1f))
            Text(valor.uppercase(), style = Letra.dato, color = s.tinta)
        }
        Separador(Modifier.fillMaxWidth().height(1.dp))
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun Calendario(mes: YearMonth, estado: EstadoShabit, ficha: Ficha, color: Color, alTocar: (LocalDate, Tipo) -> Unit) {
    val s = LocalSuelo.current
    val orden = diasDeSemana(estado.ajustes.primerDia)
    val hueco = orden.indexOf(mes.atDay(1).dayOfWeek)
    val celdas = hueco + mes.lengthOfMonth()
    Column {
        Row(Modifier.fillMaxWidth()) {
            orden.forEach {
                Text(inicial(it), style = Letra.etiqueta, color = s.tintaSuave, textAlign = TextAlign.Center, modifier = Modifier.weight(1f))
            }
        }
        Spacer(Modifier.height(4.dp))
        for (fila in 0 until (celdas + 6) / 7) {
            Row(Modifier.fillMaxWidth()) {
                for (col in 0 until 7) {
                    val i = fila * 7 + col - hueco
                    Box(Modifier.weight(1f).aspectRatio(1f).padding(2.dp)) {
                        if (i in 0 until mes.lengthOfMonth()) {
                            val dia = mes.atDay(i + 1)
                            val futuro = dia.isAfter(estado.hoy)
                            val t = tipo(ficha, dia)
                            Canvas(
                                Modifier
                                    .fillMaxSize()
                                    .semantics {
                                        contentDescription = "${ficha.habito.nombre}, ${fechaLarga(dia)}"
                                        stateDescription = when (t) { Tipo.HECHO -> "hecho"; Tipo.DESCANSO -> "descanso"; null -> "sin marcar" }
                                    }
                                    .combinedClickable(
                                        enabled = !futuro, role = Role.Checkbox,
                                        onLongClick = { alTocar(dia, Tipo.DESCANSO) },
                                        onClick = { alTocar(dia, Tipo.HECHO) },
                                    ),
                            ) {
                                if (!futuro) discoDeFrente(center, size.minDimension * 0.42f, color, t, s, agujero = false)
                                if (dia == estado.hoy) {
                                    drawCircle(s.tinta, size.minDimension * 0.48f, center, style = androidx.compose.ui.graphics.drawscope.Stroke(1.5.dp.toPx()))
                                }
                            }
                            Text(
                                "${i + 1}", style = Letra.dato.copy(fontSize = 15.sp),
                                color = if (t == Tipo.HECHO) com.serenaesteve.shabit.iu.tema.tintaSobre(color)
                                else s.tintaSuave.copy(alpha = if (futuro) 0.35f else 1f),
                                modifier = Modifier.align(Alignment.Center),
                            )
                        }
                    }
                }
            }
        }
    }
}
