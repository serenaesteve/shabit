package com.serenaesteve.shabit.dominio

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.temporal.TemporalAdjusters

/**
 * Cálculos de progreso de un hábito. No dependen de Android para poder probarse
 * con JUnit en la JVM. Los días se representan como LocalDate.toEpochDay().
 *
 * Los días de descanso no cuentan como cumplidos, pero tampoco rompen la racha,
 * y rebajan el objetivo de su semana: con 2 descansos solo quedan 5 días posibles.
 */
object Progreso {

    fun inicioSemana(fecha: LocalDate, primerDia: DayOfWeek): LocalDate =
        fecha.with(TemporalAdjusters.previousOrSame(primerDia))

    /** Días de un conjunto entre dos fechas, ambas incluidas. */
    fun contarEntre(dias: Set<Long>, desde: LocalDate, hasta: LocalDate): Int {
        val a = desde.toEpochDay()
        val b = hasta.toEpochDay()
        return dias.count { it in a..b }
    }

    fun hechasEstaSemana(hechos: Set<Long>, hoy: LocalDate, primerDia: DayOfWeek): Int {
        val ini = inicioSemana(hoy, primerDia)
        return contarEntre(hechos, ini, ini.plusDays(6))
    }

    /**
     * Días seguidos cumplidos hasta hoy. Si hoy aún no está marcado, la racha
     * sigue viva y se cuenta desde ayer: el día no ha terminado.
     */
    fun rachaDias(hechos: Set<Long>, descansos: Set<Long>, hoy: LocalDate): Int {
        var d = hoy.toEpochDay()
        if (d !in hechos && d !in descansos) d -= 1
        var n = 0
        while (true) {
            when (d) {
                in hechos -> n++
                in descansos -> Unit
                else -> return n
            }
            d--
        }
    }

    fun mejorRachaDias(hechos: Set<Long>, descansos: Set<Long>): Int {
        var mejor = 0
        var actual = 0
        var anterior = Long.MIN_VALUE
        for (d in (hechos + descansos).sorted()) {
            if (d != anterior + 1) actual = 0
            if (d in hechos) actual++
            if (actual > mejor) mejor = actual
            anterior = d
        }
        return mejor
    }

    /**
     * Primer día que cuenta para el hábito: el de creación o el primer registro,
     * si se marcó algún día anterior a crearlo.
     */
    fun inicioEfectivo(hechos: Set<Long>, descansos: Set<Long>, creado: Long): Long =
        minOf(creado, hechos.minOrNull() ?: creado, descansos.minOrNull() ?: creado)

    /**
     * Objetivo exigible en una semana: el objetivo, pero como mucho los días
     * disponibles (sin contar los anteriores al inicio ni los de descanso).
     * Devuelve null si la semana no tenía ningún día disponible: no cuenta.
     */
    fun objetivoDeSemana(ini: LocalDate, inicio: Long, objetivo: Int, descansos: Set<Long>): Int? {
        val desde = maxOf(ini.toEpochDay(), inicio)
        val hasta = ini.plusDays(6).toEpochDay()
        if (desde > hasta) return null
        val disponibles = (hasta - desde + 1).toInt() - descansos.count { it in desde..hasta }
        return if (disponibles <= 0) null else minOf(objetivo, disponibles)
    }

    private fun cumplida(ini: LocalDate, hechos: Set<Long>, descansos: Set<Long>, inicio: Long, objetivo: Int): Boolean? {
        val meta = objetivoDeSemana(ini, inicio, objetivo, descansos) ?: return null
        return contarEntre(hechos, ini, ini.plusDays(6)) >= meta
    }

    /**
     * Semanas seguidas con el objetivo cumplido. La semana en curso suma si ya
     * está cumplida y, si no, no rompe la racha. Las semanas de descanso completo
     * ni suman ni rompen.
     */
    fun rachaSemanas(
        hechos: Set<Long>, descansos: Set<Long>, hoy: LocalDate, objetivo: Int, primerDia: DayOfWeek, creado: Long,
    ): Int {
        val inicio = inicioEfectivo(hechos, descansos, creado)
        var ini = inicioSemana(hoy, primerDia)
        var n = 0
        if (cumplida(ini, hechos, descansos, inicio, objetivo) == true) n++
        ini = ini.minusWeeks(1)
        while (ini.plusDays(6).toEpochDay() >= inicio) {
            when (cumplida(ini, hechos, descansos, inicio, objetivo)) {
                true -> n++
                false -> return n
                null -> Unit
            }
            ini = ini.minusWeeks(1)
        }
        return n
    }

    fun mejorRachaSemanas(
        hechos: Set<Long>, descansos: Set<Long>, hoy: LocalDate, objetivo: Int, primerDia: DayOfWeek, creado: Long,
    ): Int {
        val inicio = inicioEfectivo(hechos, descansos, creado)
        var ini = inicioSemana(LocalDate.ofEpochDay(inicio), primerDia)
        val ultima = inicioSemana(hoy, primerDia)
        var mejor = 0
        var actual = 0
        while (!ini.isAfter(ultima)) {
            when (cumplida(ini, hechos, descansos, inicio, objetivo)) {
                true -> { actual++; if (actual > mejor) mejor = actual }
                false -> if (ini != ultima) actual = 0
                null -> Unit
            }
            ini = ini.plusWeeks(1)
        }
        return mejor
    }

    /**
     * Proporción de semanas con el objetivo cumplido entre las últimas [semanas].
     * La semana en curso solo cuenta si ya está cumplida. Devuelve null si
     * todavía no hay semanas que medir.
     */
    fun constancia(
        hechos: Set<Long>, descansos: Set<Long>, hoy: LocalDate, objetivo: Int, primerDia: DayOfWeek, creado: Long,
        semanas: Int = 12,
    ): Float? {
        val inicio = inicioEfectivo(hechos, descansos, creado)
        val actual = inicioSemana(hoy, primerDia)
        var cumplidas = 0
        var medidas = 0
        for (k in 0 until semanas) {
            val ini = actual.minusWeeks(k.toLong())
            if (ini.plusDays(6).toEpochDay() < inicio) break
            val ok = cumplida(ini, hechos, descansos, inicio, objetivo) ?: continue
            if (k == 0 && !ok) continue
            medidas++
            if (ok) cumplidas++
        }
        return if (medidas == 0) null else cumplidas.toFloat() / medidas
    }
}
