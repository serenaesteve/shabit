package com.serenaesteve.shabit.pasos

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import androidx.core.content.ContextCompat
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.serenaesteve.shabit.datos.Repositorio
import com.serenaesteve.shabit.datos.Tipo
import com.serenaesteve.shabit.dominio.DetectorPasos
import com.serenaesteve.shabit.dominio.EstadoPasos
import com.serenaesteve.shabit.dominio.Pasos
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withTimeoutOrNull
import java.time.LocalDate

/** Qué sensor puede contar los pasos en este móvil. */
enum class FuentePasos {
    /** TYPE_STEP_COUNTER: cuenta siempre, también con la app cerrada. */
    CONTADOR,
    /** Sin contador: se detectan con el acelerómetro mientras la app está abierta. */
    ACELEROMETRO,
    NINGUNA,
}

/** Lectura del sensor: valor total del contador o pasos nuevos del detector. */
sealed interface Lectura {
    data class Contador(val valor: Float) : Lectura
    data class Detectados(val nuevos: Int) : Lectura
}

private val Context.almacenPasos by preferencesDataStore(name = "pasos")

class Podometro(private val context: Context, private val repo: Repositorio) {
    private val sensores = context.getSystemService(SensorManager::class.java)
    private val kDia = longPreferencesKey("dia")
    private val kBase = floatPreferencesKey("base")
    private val kUltimo = floatPreferencesKey("ultimo")
    private val kAcumulado = intPreferencesKey("acumulado")
    private val kDetectados = intPreferencesKey("detectados")
    private val kAutoDia = longPreferencesKey("auto_dia")
    private val kAutoIds = stringSetPreferencesKey("auto_ids")

    val fuente: FuentePasos = when {
        sensores?.getDefaultSensor(Sensor.TYPE_STEP_COUNTER) != null -> FuentePasos.CONTADOR
        sensores?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) != null -> FuentePasos.ACELEROMETRO
        else -> FuentePasos.NINGUNA
    }

    /** El contador de pasos necesita el permiso de actividad física desde Android 10. */
    fun permiso(): Boolean = fuente != FuentePasos.CONTADOR || Build.VERSION.SDK_INT < 29 ||
        ContextCompat.checkSelfPermission(context, Manifest.permission.ACTIVITY_RECOGNITION) == PackageManager.PERMISSION_GRANTED

    val estado: Flow<EstadoPasos> = context.almacenPasos.data.map { p ->
        EstadoPasos(
            dia = p[kDia] ?: -1, base = p[kBase] ?: 0f, ultimo = p[kUltimo] ?: 0f,
            acumulado = p[kAcumulado] ?: 0, detectados = p[kDetectados] ?: 0,
        )
    }

    private suspend fun guardar(cambio: (EstadoPasos) -> EstadoPasos) {
        context.almacenPasos.edit { p ->
            val e = cambio(
                EstadoPasos(
                    p[kDia] ?: -1, p[kBase] ?: 0f, p[kUltimo] ?: 0f, p[kAcumulado] ?: 0, p[kDetectados] ?: 0,
                ),
            )
            p[kDia] = e.dia; p[kBase] = e.base; p[kUltimo] = e.ultimo
            p[kAcumulado] = e.acumulado; p[kDetectados] = e.detectados
        }
    }

    /** Guarda una lectura y marca los hábitos de pasos que ya hayan llegado a su objetivo. */
    suspend fun registrar(lectura: Lectura) {
        val hoy = LocalDate.now().toEpochDay()
        when (lectura) {
            is Lectura.Contador -> guardar { Pasos.conContador(it, lectura.valor, hoy) }
            is Lectura.Detectados -> guardar { Pasos.conDetector(it, lectura.nuevos, hoy) }
        }
        aplicar()
    }

    suspend fun pasosDeHoy(): Int = Pasos.deHoy(estado.first(), LocalDate.now().toEpochDay())

    /**
     * Marca como hecho cada hábito de pasos que llegue a su objetivo, una sola vez
     * al día: si luego lo desmarcas a mano, no se vuelve a marcar. Tampoco pisa
     * un día que hayas marcado como descanso.
     */
    suspend fun aplicar() {
        val hoy = LocalDate.now().toEpochDay()
        val pasos = pasosDeHoy()
        val listos = repo.activos().filter { it.pasos != null && pasos >= it.pasos }
        if (listos.isEmpty()) return
        val p = context.almacenPasos.data.first()
        val ya = if (p[kAutoDia] == hoy) p[kAutoIds].orEmpty() else emptySet()
        val nuevos = listos.filter { it.id.toString() !in ya }
        if (nuevos.isEmpty()) return
        for (h in nuevos) if (repo.tipo(h.id, hoy) == null) repo.marcar(h.id, hoy, Tipo.HECHO)
        context.almacenPasos.edit {
            it[kAutoDia] = hoy
            it[kAutoIds] = ya + nuevos.map { h -> h.id.toString() }
        }
    }

    /** Lecturas en vivo mientras alguien las recoge (la app abierta). */
    fun lecturas(): Flow<Lectura> = callbackFlow {
        val oyente: SensorEventListener
        val sensor: Sensor?
        when (fuente) {
            FuentePasos.CONTADOR -> {
                sensor = sensores.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)
                oyente = object : SensorEventListener {
                    override fun onSensorChanged(e: SensorEvent) { trySend(Lectura.Contador(e.values[0])) }
                    override fun onAccuracyChanged(s: Sensor?, a: Int) = Unit
                }
            }
            FuentePasos.ACELEROMETRO -> {
                sensor = sensores.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
                val detector = DetectorPasos()
                oyente = object : SensorEventListener {
                    override fun onSensorChanged(e: SensorEvent) {
                        if (detector.muestra(e.values[0], e.values[1], e.values[2], e.timestamp / 1_000_000)) {
                            trySend(Lectura.Detectados(1))
                        }
                    }
                    override fun onAccuracyChanged(s: Sensor?, a: Int) = Unit
                }
            }
            FuentePasos.NINGUNA -> { close(); return@callbackFlow }
        }
        if (!permiso()) { close(); return@callbackFlow }
        sensores.registerListener(oyente, sensor, SensorManager.SENSOR_DELAY_GAME)
        awaitClose { sensores.unregisterListener(oyente) }
    }

    /** Una sola lectura del contador, para el trabajo en segundo plano. */
    suspend fun leerContador(): Float? {
        if (fuente != FuentePasos.CONTADOR || !permiso()) return null
        return withTimeoutOrNull(10_000) {
            (lecturas().first() as? Lectura.Contador)?.valor
        }
    }
}
