package com.serenaesteve.shabit.datos

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

/** Días de un hábito separados por tipo. */
data class Dias(val hechos: Set<Long> = emptySet(), val descansos: Set<Long> = emptySet())

/**
 * Punto único de acceso a los datos para las pantallas, el widget y los trabajos
 * en segundo plano. [alCambiar] se llama tras cada escritura para refrescar el widget.
 */
class Repositorio(private val dao: HabitoDao, private val alCambiar: suspend () -> Unit = {}) {
    val habitos: Flow<List<Habito>> = dao.habitos()

    val registros: Flow<Map<Long, Dias>> = dao.registros().map { lista ->
        lista.groupBy { it.habitoId }.mapValues { (_, r) ->
            Dias(
                hechos = r.filter { it.tipo == Tipo.HECHO }.map { it.dia }.toSet(),
                descansos = r.filter { it.tipo == Tipo.DESCANSO }.map { it.dia }.toSet(),
            )
        }
    }

    suspend fun habito(id: Long) = dao.habito(id)
    suspend fun activos() = dao.activos()
    suspend fun registrosDe(dia: Long) = dao.registrosDe(dia).associate { it.habitoId to it.tipo }
    suspend fun tipo(habitoId: Long, dia: Long) = dao.tipo(habitoId, dia)

    /** Inserta o actualiza. Devuelve el id del hábito guardado. */
    suspend fun guardar(habito: Habito): Long {
        val id = if (habito.id == 0L) dao.insertar(habito.copy(orden = dao.siguienteOrden()))
        else { dao.actualizar(habito); habito.id }
        alCambiar()
        return id
    }

    suspend fun borrar(habito: Habito) { dao.borrar(habito); alCambiar() }

    suspend fun alternar(habitoId: Long, dia: Long, tipo: Tipo): Tipo? =
        dao.alternar(habitoId, dia, tipo).also { alCambiar() }

    suspend fun marcar(habitoId: Long, dia: Long, tipo: Tipo) {
        dao.guardar(Registro(habitoId, dia, tipo)); alCambiar()
    }

    suspend fun quitar(habitoId: Long, dia: Long) { dao.quitar(habitoId, dia); alCambiar() }
}
