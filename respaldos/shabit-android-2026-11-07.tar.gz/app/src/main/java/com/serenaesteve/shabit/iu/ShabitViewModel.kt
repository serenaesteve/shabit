package com.serenaesteve.shabit.iu

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.serenaesteve.shabit.ShabitApp
import com.serenaesteve.shabit.datos.Ajustes
import com.serenaesteve.shabit.datos.Dias
import com.serenaesteve.shabit.datos.Habito
import com.serenaesteve.shabit.datos.Tema
import com.serenaesteve.shabit.datos.Tipo
import com.serenaesteve.shabit.dominio.Ficha
import com.serenaesteve.shabit.dominio.Pasos
import com.serenaesteve.shabit.pasos.FuentePasos
import com.serenaesteve.shabit.recordatorios.Recordatorios
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.emptyFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.Duration
import java.time.LocalDate
import java.time.LocalDateTime

data class EstadoPasosIu(
    val fuente: FuentePasos = FuentePasos.NINGUNA,
    val permiso: Boolean = true,
    val hoy: Int = 0,
)

data class EstadoShabit(
    val cargando: Boolean = true,
    val hoy: LocalDate = LocalDate.now(),
    val ajustes: Ajustes = Ajustes(),
    val fichas: List<Ficha> = emptyList(),
    val guardados: List<Habito> = emptyList(),
    val pasos: EstadoPasosIu = EstadoPasosIu(),
) {
    fun ficha(id: Long) = fichas.firstOrNull { it.habito.id == id }
    fun tipoHoy(f: Ficha): Tipo? = tipo(f, hoy)
    val hayPasos: Boolean get() = fichas.any { it.habito.pasos != null }
}

fun tipo(f: Ficha, dia: LocalDate): Tipo? {
    val d = dia.toEpochDay()
    return when (d) {
        in f.hechos -> Tipo.HECHO
        in f.descansos -> Tipo.DESCANSO
        else -> null
    }
}

/**
 * Estado compartido por todas las pantallas. Combina hábitos, registros,
 * preferencias, pasos y la fecha de hoy, y recalcula el progreso cuando cambia algo.
 */
@OptIn(ExperimentalCoroutinesApi::class, FlowPreview::class)
class ShabitViewModel(app: Application) : AndroidViewModel(app) {
    private val contenedor = app as ShabitApp
    private val repo = contenedor.repositorio
    private val prefs = contenedor.preferencias
    private val podometro = contenedor.podometro
    private val hoy = MutableStateFlow(LocalDate.now())
    private val permisoPasos = MutableStateFlow(podometro.permiso())

    private val pasos = combine(podometro.estado, hoy, permisoPasos) { e, dia, permiso ->
        EstadoPasosIu(podometro.fuente, permiso, Pasos.deHoy(e, dia.toEpochDay()))
    }

    val estado: StateFlow<EstadoShabit> = combine(
        repo.habitos, repo.registros, prefs.ajustes, hoy, pasos,
    ) { habitos, registros, ajustes, dia, p ->
        EstadoShabit(
            cargando = false,
            hoy = dia,
            ajustes = ajustes,
            fichas = habitos.filterNot { it.archivado }.map {
                Ficha.de(it, registros[it.id] ?: Dias(), dia, ajustes.primerDia)
            },
            guardados = habitos.filter { it.archivado },
            pasos = p,
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), EstadoShabit())

    init {
        // Cambia de día a medianoche aunque la app siga abierta.
        viewModelScope.launch {
            while (true) {
                val ahora = LocalDateTime.now()
                val manana = ahora.toLocalDate().plusDays(1).atStartOfDay()
                delay(Duration.between(ahora, manana).toMillis() + 500)
                hoy.value = LocalDate.now()
            }
        }
        // Mientras haya algún hábito de pasos y la app esté abierta, se leen en vivo.
        repo.habitos
            .map { lista -> lista.any { !it.archivado && it.pasos != null } }
            .combine(permisoPasos) { hay, permiso -> hay && permiso }
            .flatMapLatest { activo -> if (activo) podometro.lecturas() else emptyFlow() }
            .onEach { podometro.registrar(it) }
            .launchIn(viewModelScope)
    }

    /** Se llama al volver a la app: puede haber cambiado el día o el permiso. */
    fun refrescar() {
        hoy.value = LocalDate.now()
        permisoPasos.value = podometro.permiso()
    }

    fun alternar(habitoId: Long, dia: LocalDate, tipo: Tipo) = viewModelScope.launch {
        repo.alternar(habitoId, dia.toEpochDay(), tipo)
    }

    /**
     * Día de descanso para todo: marca como descanso los hábitos sin marcar hoy.
     * Si ya no queda ninguno sin marcar, quita los descansos de hoy.
     */
    fun descansoHoy() = viewModelScope.launch {
        val e = estado.value
        val d = e.hoy.toEpochDay()
        val pendientes = e.fichas.filter { e.tipoHoy(it) == null }
        if (pendientes.isNotEmpty()) pendientes.forEach { repo.marcar(it.habito.id, d, Tipo.DESCANSO) }
        else e.fichas.filter { e.tipoHoy(it) == Tipo.DESCANSO }.forEach { repo.quitar(it.habito.id, d) }
    }

    fun guardar(habito: Habito, alTerminar: (Long) -> Unit = {}) = viewModelScope.launch {
        val id = repo.guardar(habito)
        Recordatorios.programar(getApplication(), habito.copy(id = id))
        podometro.aplicar()
        alTerminar(id)
    }

    fun archivar(habito: Habito, archivado: Boolean) = guardar(habito.copy(archivado = archivado))

    fun borrar(habito: Habito) = viewModelScope.launch {
        Recordatorios.cancelar(getApplication(), habito.id)
        repo.borrar(habito)
    }

    fun tema(tema: Tema) = viewModelScope.launch { prefs.tema(tema) }
    fun semanaEnDomingo(si: Boolean) = viewModelScope.launch { prefs.semanaEnDomingo(si) }
    fun vibracion(si: Boolean) = viewModelScope.launch { prefs.vibracion(si) }
}
