package com.serenaesteve.shabit.widget

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.ColorFilter
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.Image
import androidx.glance.ImageProvider
import androidx.glance.action.ActionParameters
import androidx.glance.action.actionParametersOf
import androidx.glance.action.actionStartActivity
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.action.ActionCallback
import androidx.glance.appwidget.action.actionRunCallback
import androidx.glance.appwidget.lazy.LazyColumn
import androidx.glance.appwidget.lazy.items
import androidx.glance.appwidget.provideContent
import androidx.glance.appwidget.updateAll
import androidx.glance.background
import androidx.glance.layout.Alignment
import androidx.glance.layout.Column
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.layout.size
import androidx.glance.layout.width
import androidx.glance.text.FontFamily
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import com.serenaesteve.shabit.ShabitApp
import com.serenaesteve.shabit.MainActivity
import com.serenaesteve.shabit.R
import com.serenaesteve.shabit.datos.Habito
import com.serenaesteve.shabit.datos.Tipo
import com.serenaesteve.shabit.iu.tema.colorDisco
import java.time.LocalDate

private val fondo = Color(0xFF151619)
private val tinta = Color(0xFFF1F0EC)
private val suave = Color(0xFF8E939B)
private val condensada = FontFamily("sans-serif-condensed")
private val claveId = ActionParameters.Key<Long>("habito")

/** Widget de la pantalla de inicio: los hábitos de hoy, con un toque para cargar el disco. */
class WidgetHoy : GlanceAppWidget() {
    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val repo = (context.applicationContext as ShabitApp).repositorio
        val iniciales = repo.activos()
        val registrosIniciales = repo.registrosDe(LocalDate.now().toEpochDay())
        provideContent {
            // Glance mantiene la sesión abierta un rato: se leen flujos de Room para que
            // cualquier cambio (desde la app, el widget o el podómetro) se vea al momento.
            val habitos by repo.habitos.collectAsState(null)
            val registros by repo.registros.collectAsState(null)
            val dia = LocalDate.now().toEpochDay()
            val activos = habitos?.filterNot { it.archivado } ?: iniciales
            val hoy = registros?.let { r ->
                activos.mapNotNull { h ->
                    val d = r[h.id] ?: return@mapNotNull null
                    when (dia) {
                        in d.hechos -> h.id to Tipo.HECHO
                        in d.descansos -> h.id to Tipo.DESCANSO
                        else -> null
                    }
                }.toMap()
            } ?: registrosIniciales
            Contenido(activos, hoy)
        }
    }

    companion object {
        suspend fun actualizar(context: Context) = WidgetHoy().updateAll(context)
    }
}

@Composable
private fun Contenido(habitos: List<Habito>, hoy: Map<Long, Tipo>) {
    val hechos = habitos.count { hoy[it.id] == Tipo.HECHO }
    Column(GlanceModifier.fillMaxSize().background(fondo).padding(14.dp)) {
        Row(
            GlanceModifier.fillMaxWidth().clickable(actionStartActivity<MainActivity>()),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("HOY", style = TextStyle(color = ColorProvider(tinta), fontSize = 20.sp, fontWeight = FontWeight.Bold, fontFamily = condensada))
            Spacer(GlanceModifier.defaultWeight())
            if (habitos.isNotEmpty()) {
                Text(
                    "$hechos/${habitos.size}",
                    style = TextStyle(color = ColorProvider(tinta), fontSize = 18.sp, fontWeight = FontWeight.Bold, fontFamily = condensada),
                )
            }
        }
        Spacer(GlanceModifier.height(6.dp))
        if (habitos.isEmpty()) {
            Text(
                "Abre shabit y crea tu primer hábito.",
                style = TextStyle(color = ColorProvider(suave), fontSize = 14.sp),
                modifier = GlanceModifier.clickable(actionStartActivity<MainActivity>()),
            )
        } else {
            LazyColumn {
                items(habitos, itemId = { it.id }) { h -> Fila(h, hoy[h.id]) }
            }
        }
    }
}

@Composable
private fun Fila(h: Habito, tipo: Tipo?) {
    val color = colorDisco(h.color)
    Row(
        GlanceModifier
            .fillMaxWidth()
            .padding(vertical = 5.dp)
            .clickable(actionRunCallback<AlternarHoy>(actionParametersOf(claveId to h.id))),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Image(
            provider = ImageProvider(
                when (tipo) {
                    Tipo.HECHO -> R.drawable.disco_lleno
                    Tipo.DESCANSO -> R.drawable.disco_descanso
                    null -> R.drawable.disco_vacio
                },
            ),
            contentDescription = "${h.nombre}: " + when (tipo) { Tipo.HECHO -> "hecho"; Tipo.DESCANSO -> "descanso"; null -> "sin marcar" },
            colorFilter = ColorFilter.tint(ColorProvider(if (tipo == Tipo.HECHO) color else suave)),
            modifier = GlanceModifier.size(30.dp),
        )
        Spacer(GlanceModifier.width(10.dp))
        Text(
            h.nombre.uppercase(),
            style = TextStyle(
                color = ColorProvider(if (tipo == null) tinta else suave),
                fontSize = 16.sp, fontWeight = FontWeight.Medium, fontFamily = condensada,
            ),
            maxLines = 1,
        )
    }
}

/** Toque en una fila del widget: carga o quita el disco de hoy. */
class AlternarHoy : ActionCallback {
    override suspend fun onAction(context: Context, glanceId: GlanceId, parameters: ActionParameters) {
        val id = parameters[claveId] ?: return
        val repo = (context.applicationContext as ShabitApp).repositorio
        repo.alternar(id, LocalDate.now().toEpochDay(), Tipo.HECHO)
    }
}

class WidgetHoyReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = WidgetHoy()
}
