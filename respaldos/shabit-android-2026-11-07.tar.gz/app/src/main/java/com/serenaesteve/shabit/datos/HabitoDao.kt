package com.serenaesteve.shabit.datos

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface HabitoDao {
    @Query("SELECT * FROM habitos ORDER BY archivado, orden, id")
    fun habitos(): Flow<List<Habito>>

    @Query("SELECT * FROM habitos WHERE archivado = 0 ORDER BY orden, id")
    suspend fun activos(): List<Habito>

    @Query("SELECT * FROM habitos WHERE id = :id")
    suspend fun habito(id: Long): Habito?

    @Query("SELECT COALESCE(MAX(orden), -1) + 1 FROM habitos")
    suspend fun siguienteOrden(): Int

    @Insert
    suspend fun insertar(habito: Habito): Long

    @Update
    suspend fun actualizar(habito: Habito)

    @Delete
    suspend fun borrar(habito: Habito)

    @Query("SELECT * FROM registros")
    fun registros(): Flow<List<Registro>>

    @Query("SELECT * FROM registros WHERE dia = :dia")
    suspend fun registrosDe(dia: Long): List<Registro>

    @Query("SELECT tipo FROM registros WHERE habitoId = :habitoId AND dia = :dia")
    suspend fun tipo(habitoId: Long, dia: Long): Tipo?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun guardar(registro: Registro)

    @Query("DELETE FROM registros WHERE habitoId = :habitoId AND dia = :dia")
    suspend fun quitar(habitoId: Long, dia: Long)

    /**
     * Si el día ya tiene ese tipo, lo deja vacío; si no, lo pone.
     * Así, tocar dos veces deshace y un descanso puede pasar a hecho directamente.
     */
    @Transaction
    suspend fun alternar(habitoId: Long, dia: Long, tipo: Tipo): Tipo? {
        return if (tipo(habitoId, dia) == tipo) {
            quitar(habitoId, dia); null
        } else {
            guardar(Registro(habitoId, dia, tipo)); tipo
        }
    }
}
