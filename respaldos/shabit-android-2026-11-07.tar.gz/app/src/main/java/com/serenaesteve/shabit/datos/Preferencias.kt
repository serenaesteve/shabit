package com.serenaesteve.shabit.datos

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.time.DayOfWeek

enum class Tema { SISTEMA, MAGNESIO, GOMA }

data class Ajustes(
    val tema: Tema = Tema.SISTEMA,
    val primerDia: DayOfWeek = DayOfWeek.MONDAY,
    val vibracion: Boolean = true,
)

private val Context.almacen by preferencesDataStore(name = "ajustes")

/** Preferencias de la aplicación guardadas con DataStore. */
class Preferencias(private val context: Context) {
    private val claveTema = intPreferencesKey("tema")
    private val claveDomingo = booleanPreferencesKey("semana_en_domingo")
    private val claveVibracion = booleanPreferencesKey("vibracion")

    val ajustes: Flow<Ajustes> = context.almacen.data.map { p ->
        Ajustes(
            tema = Tema.entries.getOrElse(p[claveTema] ?: 0) { Tema.SISTEMA },
            primerDia = if (p[claveDomingo] == true) DayOfWeek.SUNDAY else DayOfWeek.MONDAY,
            vibracion = p[claveVibracion] ?: true,
        )
    }

    suspend fun tema(tema: Tema) = context.almacen.edit { it[claveTema] = tema.ordinal }
    suspend fun semanaEnDomingo(si: Boolean) = context.almacen.edit { it[claveDomingo] = si }
    suspend fun vibracion(si: Boolean) = context.almacen.edit { it[claveVibracion] = si }
}
