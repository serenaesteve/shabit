package com.serenaesteve.shabit.pasos

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.serenaesteve.shabit.ShabitApp
import java.util.concurrent.TimeUnit

/**
 * Cada 15 minutos (el mínimo de WorkManager) lee el contador de pasos aunque
 * la app esté cerrada, para fijar la base del día cerca de la medianoche y
 * marcar los hábitos de pasos sin tener que abrir la app.
 */
class PasosWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        val app = applicationContext as ShabitApp
        // De paso, refresca el widget: así cambia de día poco después de medianoche.
        com.serenaesteve.shabit.widget.WidgetHoy.actualizar(applicationContext)
        if (app.repositorio.activos().none { it.pasos != null }) return Result.success()
        val valor = app.podometro.leerContador() ?: return Result.success()
        app.podometro.registrar(Lectura.Contador(valor))
        return Result.success()
    }

    companion object {
        fun programar(context: Context) {
            val pedido = PeriodicWorkRequestBuilder<PasosWorker>(15, TimeUnit.MINUTES).build()
            WorkManager.getInstance(context)
                .enqueueUniquePeriodicWork("pasos", ExistingPeriodicWorkPolicy.KEEP, pedido)
        }
    }
}
