package com.serenaesteve.shabit.iu.gimnasio

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.serenaesteve.shabit.datos.Tipo
import com.serenaesteve.shabit.dominio.Progreso
import com.serenaesteve.shabit.iu.tema.Letra
import com.serenaesteve.shabit.iu.tema.LocalSuelo
import com.serenaesteve.shabit.iu.tema.Suelo
import java.time.DayOfWeek
import java.time.LocalDate
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

/** Suelo de goma de gimnasio: fondo liso con motas de caucho reciclado. */
fun Modifier.goma(s: Suelo): Modifier = drawWithCache {
    val r = Random(11)
    val n = (size.width * size.height / (11.dp.toPx() * 11.dp.toPx())).toInt()
    val motas = List(n) {
        Triple(
            Offset(r.nextFloat() * size.width, r.nextFloat() * size.height),
            (0.6f + r.nextFloat() * 1.3f).dp.toPx(),
            s.motas[r.nextInt(s.motas.size)],
        )
    }
    onDrawBehind {
        drawRect(s.fondo)
        motas.forEach { (o, radio, c) -> drawCircle(c, radio, o) }
    }
}

/**
 * Disco visto de lado sobre la manga de la barra. [avance] va de 0 a 1: el
 * disco cae desde arriba y se asienta. [alto] es la altura del disco completo.
 */
fun DrawScope.discoDeLado(centro: Offset, ancho: Float, alto: Float, color: Color, avance: Float) {
    if (avance <= 0f) return
    val caida = (1f - avance) * -alto * 0.7f
    val alfa = avance.coerceIn(0f, 1f)
    val tl = Offset(centro.x - ancho / 2, centro.y - alto / 2 + caida)
    val radio = CornerRadius(ancho * 0.28f)
    drawRoundRect(Color.Black.copy(alpha = 0.28f * alfa), tl + Offset(ancho * 0.12f, alto * 0.03f), Size(ancho, alto), radio)
    drawRoundRect(color.copy(alpha = alfa), tl, Size(ancho, alto), radio)
    // Canto con brillo a la izquierda y sombra a la derecha, como la goma de un bumper.
    drawRoundRect(lerp(color, Color.White, 0.35f).copy(alpha = 0.7f * alfa), tl + Offset(ancho * 0.12f, alto * 0.06f), Size(ancho * 0.14f, alto * 0.88f), CornerRadius(ancho * 0.07f))
    drawRoundRect(lerp(color, Color.Black, 0.3f).copy(alpha = 0.6f * alfa), tl + Offset(ancho * 0.74f, alto * 0.06f), Size(ancho * 0.12f, alto * 0.88f), CornerRadius(ancho * 0.06f))
    // Inserto de acero del centro.
    val acero = Color(0xFFC9CDD3)
    drawRect(acero.copy(alpha = alfa), Offset(centro.x - ancho * 0.58f, centro.y - alto * 0.09f + caida), Size(ancho * 1.16f, alto * 0.18f))
}

/** Disco de descarga: más bajo, gris y rayado, para los días de descanso. */
fun DrawScope.discoDescanso(centro: Offset, ancho: Float, alto: Float, s: Suelo, avance: Float) {
    if (avance <= 0f) return
    val h = alto * 0.5f
    val w = ancho * 0.7f
    val tl = Offset(centro.x - w / 2, centro.y - h / 2)
    val c = s.tintaSuave.copy(alpha = 0.55f * avance)
    drawRoundRect(c, tl, Size(w, h), CornerRadius(w * 0.25f), style = Stroke(1.5.dp.toPx()))
    clipRect(tl.x, tl.y, tl.x + w, tl.y + h) {
        var y = tl.y - w
        while (y < tl.y + h) {
            drawLine(c, Offset(tl.x, y + w), Offset(tl.x + w, y), 1.dp.toPx())
            y += 4.dp.toPx()
        }
    }
}

/**
 * Hueco de un día en la barra. Tocar carga o quita el disco; mantener pulsado
 * marca o quita el descanso. La manga se dibuja de borde a borde para que los
 * huecos contiguos formen una barra continua.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun HuecoDisco(
    tipo: Tipo?,
    color: Color,
    descripcion: String,
    modifier: Modifier = Modifier,
    alto: Dp = 56.dp,
    destacado: Boolean = false,
    activo: Boolean = true,
    alTocar: () -> Unit,
    alMantener: () -> Unit,
) {
    val s = LocalSuelo.current
    val hecho = remember { Animatable(if (tipo == Tipo.HECHO) 1f else 0f) }
    val descanso = remember { Animatable(if (tipo == Tipo.DESCANSO) 1f else 0f) }
    LaunchedEffect(tipo) {
        if (tipo == Tipo.HECHO) hecho.animateTo(1f, spring(dampingRatio = 0.45f, stiffness = Spring.StiffnessMediumLow))
        else hecho.animateTo(0f, tween(160))
    }
    LaunchedEffect(tipo) { descanso.animateTo(if (tipo == Tipo.DESCANSO) 1f else 0f, tween(220)) }

    Canvas(
        modifier
            .size(width = alto * 0.62f, height = alto)
            .semantics {
                contentDescription = descripcion
                stateDescription = when (tipo) { Tipo.HECHO -> "hecho"; Tipo.DESCANSO -> "descanso"; null -> "sin marcar" }
            }
            .combinedClickable(
                enabled = activo,
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                role = Role.Checkbox,
                onLongClickLabel = "Marcar descanso",
                onLongClick = alMantener,
                onClick = alTocar,
            ),
    ) {
        val c = center
        val manga = 5.dp.toPx()
        drawRect(s.aceroOscuro, Offset(0f, c.y - manga / 2), Size(size.width, manga))
        drawRect(s.acero.copy(alpha = 0.5f), Offset(0f, c.y - manga / 2), Size(size.width, manga * 0.35f))
        val ancho = size.width * 0.5f
        val h = if (destacado) size.height * 0.94f else size.height * 0.8f
        if (destacado && tipo == null) {
            drawRoundRect(
                s.tinta.copy(alpha = 0.7f), Offset(c.x - ancho / 2, c.y - h / 2), Size(ancho, h), CornerRadius(ancho * 0.28f),
                style = Stroke(1.5.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 7f))),
            )
        }
        discoDescanso(c, ancho, h, s, descanso.value)
        discoDeLado(c, ancho, h, color.copy(alpha = if (activo) 1f else 0.4f), hecho.value)
    }
}

/** Disco visto de frente, pequeño: para el calendario y el selector de color. */
fun DrawScope.discoDeFrente(centro: Offset, radio: Float, color: Color, tipo: Tipo?, s: Suelo, agujero: Boolean = true) {
    when (tipo) {
        Tipo.HECHO -> {
            drawCircle(Color.Black.copy(alpha = 0.25f), radio, centro + Offset(radio * 0.06f, radio * 0.1f))
            drawCircle(color, radio, centro)
            drawCircle(lerp(color, Color.Black, 0.22f), radio * 0.78f, centro, style = Stroke(radio * 0.08f))
            if (agujero) {
                drawCircle(Color(0xFFC9CDD3), radio * 0.3f, centro)
                drawCircle(lerp(color, Color.Black, 0.5f), radio * 0.13f, centro)
            }
        }
        Tipo.DESCANSO -> {
            drawCircle(s.tintaSuave.copy(alpha = 0.6f), radio * 0.62f, centro, style = Stroke(1.5.dp.toPx()))
            drawLine(s.tintaSuave.copy(alpha = 0.6f), centro + Offset(-radio * 0.42f, radio * 0.42f), centro + Offset(radio * 0.42f, -radio * 0.42f), 1.5.dp.toPx())
        }
        null -> drawCircle(s.linea, radio * 0.62f, centro, style = Stroke(1.5.dp.toPx()))
    }
}

/**
 * Disco grande de frente que resume el día: cada hábito ocupa un tramo del
 * borde y se enciende con su color cuando está hecho.
 */
@Composable
fun DiscoResumen(tramos: List<Pair<Color, Tipo?>>, modifier: Modifier = Modifier, contenido: @Composable () -> Unit) {
    val s = LocalSuelo.current
    val hechos = tramos.count { it.second == Tipo.HECHO }
    val f by animateFloatAsState(hechos.toFloat(), tween(500), label = "resumen")
    Box(modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.matchParentSize()) {
            val r = size.minDimension / 2
            val c = center
            drawCircle(s.franja, r, c)
            drawCircle(s.linea, r, c, style = Stroke(1.dp.toPx()))
            val n = tramos.size.coerceAtLeast(1)
            val hueco = if (n == 1) 0f else 6f
            val barrido = 360f / n - hueco
            val grosor = r * 0.2f
            tramos.forEachIndexed { i, (color, tipo) ->
                val inicio = -90f + i * 360f / n + hueco / 2
                val encendido = tipo == Tipo.HECHO
                drawArc(
                    color = when {
                        encendido -> color
                        tipo == Tipo.DESCANSO -> s.tintaSuave.copy(alpha = 0.35f)
                        else -> s.aceroOscuro.copy(alpha = 0.35f)
                    },
                    startAngle = inicio, sweepAngle = barrido, useCenter = false,
                    topLeft = Offset(c.x - r + grosor / 2 + 3.dp.toPx(), c.y - r + grosor / 2 + 3.dp.toPx()),
                    size = Size(2 * r - grosor - 6.dp.toPx(), 2 * r - grosor - 6.dp.toPx()),
                    style = Stroke(grosor),
                )
            }
            // Agujero central de 50 mm, con su aro de acero.
            drawCircle(Color(0xFFC9CDD3), r * 0.2f, c)
            drawCircle(s.franja, r * 0.12f, c)
            // Remaches del inserto.
            for (k in 0 until 6) {
                val a = k * PI / 3
                drawCircle(Color(0xFFC9CDD3).copy(alpha = 0.6f), r * 0.025f, Offset(c.x + r * 0.27f * cos(a).toFloat(), c.y + r * 0.27f * sin(a).toFloat()))
            }
            if (f >= n && tramos.isNotEmpty()) drawCircle(s.tinta.copy(alpha = 0.15f), r, c, style = Stroke(2.dp.toPx()))
        }
        contenido()
    }
}

/**
 * Pilas de discos por semana: cada columna es una semana y cada disco tumbado,
 * un día hecho. La línea discontinua marca el objetivo semanal.
 */
@Composable
fun PilasSemanas(
    hechos: Set<Long>, descansos: Set<Long>, hoy: LocalDate, primerDia: DayOfWeek, desde: Long,
    objetivo: Int, color: Color, modifier: Modifier = Modifier, anchoColumna: Dp = 22.dp,
) {
    val s = LocalSuelo.current
    Canvas(modifier) {
        val col = anchoColumna.toPx()
        val columnas = (size.width / col).toInt().coerceAtLeast(1)
        val losa = (size.height - 10.dp.toPx()) / 7f
        val suelo = size.height - 6.dp.toPx()
        val actual = Progreso.inicioSemana(hoy, primerDia)
        for (k in 0 until columnas) {
            val ini = actual.minusWeeks((columnas - 1 - k).toLong())
            val x = k * col
            if (ini.plusDays(6).toEpochDay() < desde) {
                drawLine(s.linea, Offset(x + col * 0.2f, suelo), Offset(x + col * 0.8f, suelo), 1.dp.toPx())
                continue
            }
            var y = suelo
            var n = 0
            for (d in 0 until 7) {
                val dia = ini.plusDays(d.toLong()).toEpochDay()
                if (dia in hechos) {
                    y -= losa
                    drawRoundRect(color, Offset(x + col * 0.12f, y + losa * 0.12f), Size(col * 0.76f, losa * 0.8f), CornerRadius(losa * 0.3f))
                    drawRect(lerp(color, Color.White, 0.3f).copy(alpha = 0.6f), Offset(x + col * 0.2f, y + losa * 0.18f), Size(col * 0.6f, losa * 0.12f))
                    n++
                }
            }
            for (d in 0 until 7) {
                val dia = ini.plusDays(d.toLong()).toEpochDay()
                if (dia in descansos) {
                    y -= losa * 0.5f
                    drawRoundRect(s.tintaSuave.copy(alpha = 0.45f), Offset(x + col * 0.24f, y + losa * 0.1f), Size(col * 0.52f, losa * 0.32f), CornerRadius(losa * 0.15f))
                }
            }
            if (ini == actual) {
                val p = suelo + 4.dp.toPx()
                drawLine(s.tinta, Offset(x + col * 0.3f, p), Offset(x + col * 0.7f, p), 2.dp.toPx(), StrokeCap.Round)
            }
        }
        val yObjetivo = suelo - objetivo * losa
        drawLine(
            s.tinta.copy(alpha = 0.55f), Offset(0f, yObjetivo), Offset(columnas * col, yObjetivo), 1.dp.toPx(),
            pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 6f)),
        )
        drawLine(s.aceroOscuro, Offset(0f, suelo), Offset(columnas * col, suelo), 1.dp.toPx())
    }
}

/** Progreso hacia la meta como una barra: la parte cargada es del color del disco. */
@Composable
fun BarraMeta(fraccion: Float, color: Color, modifier: Modifier = Modifier) {
    val s = LocalSuelo.current
    val f by animateFloatAsState(fraccion.coerceIn(0f, 1f), tween(700), label = "meta")
    Canvas(modifier) {
        val y = size.height / 2
        val fina = 4.dp.toPx()
        drawLine(s.aceroOscuro, Offset(0f, y), Offset(size.width, y), fina)
        // Moleteado de la barra: marcas finas cada pocos píxeles.
        var x = 0f
        while (x < size.width) {
            drawLine(s.acero.copy(alpha = 0.35f), Offset(x, y - fina / 2), Offset(x + 2.dp.toPx(), y + fina / 2), 0.7.dp.toPx())
            x += 4.dp.toPx()
        }
        if (f > 0f) drawLine(color, Offset(0f, y), Offset(size.width * f, y), size.height * 0.7f, StrokeCap.Butt)
        drawRect(s.acero, Offset(size.width * f - 2.dp.toPx(), 0f), Size(4.dp.toPx(), size.height))
    }
}

/** Botón rectangular con rótulo de gimnasio. */
@Composable
fun Boton(
    texto: String, alTocar: () -> Unit, modifier: Modifier = Modifier,
    relleno: Boolean = false, color: Color? = null,
) {
    val s = LocalSuelo.current
    val tinta = color ?: s.tinta
    val textoColor = if (relleno) com.serenaesteve.shabit.iu.tema.tintaSobre(tinta) else tinta
    Box(
        modifier
            .drawBehind {
                val r = CornerRadius(3.dp.toPx())
                if (relleno) drawRoundRect(tinta, cornerRadius = r)
                else drawRoundRect(tinta, cornerRadius = r, style = Stroke(1.5.dp.toPx()))
            }
            .clickable(role = Role.Button, onClick = alTocar)
            .padding(horizontal = 18.dp, vertical = 13.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(texto.uppercase(), style = Letra.dato, color = textoColor)
    }
}

/** Línea fina que separa bloques. */
@Composable
fun Separador(modifier: Modifier = Modifier) {
    val s = LocalSuelo.current
    Canvas(modifier) { drawLine(s.linea, Offset(0f, size.height / 2), Offset(size.width, size.height / 2), 1.dp.toPx()) }
}
