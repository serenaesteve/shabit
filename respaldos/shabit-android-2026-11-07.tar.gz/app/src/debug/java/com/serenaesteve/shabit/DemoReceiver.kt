package com.serenaesteve.shabit

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.workDataOf
import com.serenaesteve.shabit.datos.Habito
import com.serenaesteve.shabit.datos.Tipo
import com.serenaesteve.shabit.recordatorios.RecordatorioWorker
import com.serenaesteve.shabit.recordatorios.Recordatorios
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.time.LocalDate
import kotlin.random.Random

/**
 * Herramienta de desarrollo, solo en debug:
 *   adb shell am broadcast -n com.serenaesteve.shabit/.DemoReceiver              → 14 semanas de datos de ejemplo
 *   adb shell am broadcast -n com.serenaesteve.shabit/.DemoReceiver --el aviso 1 → lanza ya el aviso del hábito 1
 *   adb shell am broadcast -n com.serenaesteve.shabit/.DemoReceiver --ei pasos 500 → suma pasos detectados
 */
class DemoReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val app = context.applicationContext as ShabitApp
        val aviso = intent.getLongExtra("aviso", -1)
        if (aviso > 0) {
            WorkManager.getInstance(app).enqueue(
                OneTimeWorkRequestBuilder<RecordatorioWorker>()
                    .setInputData(workDataOf(RecordatorioWorker.HABITO to aviso)).build(),
            )
            return
        }
        val pasos = intent.getIntExtra("pasos", 0)
        if (pasos > 0) {
            val p = goAsync()
            CoroutineScope(Dispatchers.IO).launch {
                try { app.podometro.registrar(com.serenaesteve.shabit.pasos.Lectura.Detectados(pasos)) } finally { p.finish() }
            }
            return
        }
        val pendiente = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                app.baseDatos.clearAllTables()
                val hoy = LocalDate.now()
                val r = Random(7)
                data class Demo(val nombre: String, val color: Int, val objetivo: Int, val meta: Int, val semanas: Int, val p: Double, val pasos: Int? = null)
                listOf(
                    Demo("Caminar", 3, 7, 100, 10, 0.86, pasos = 8000),
                    Demo("Leer 20 minutos", 1, 5, 100, 14, 0.74),
                    Demo("Estirar", 2, 4, 66, 8, 0.6),
                    Demo("Sin pantallas al dormir", 6, 4, 30, 5, 0.55),
                ).forEach { d ->
                    val creado = hoy.minusWeeks(d.semanas.toLong())
                    val id = app.repositorio.guardar(
                        Habito(
                            nombre = d.nombre, color = d.color, objetivoSemanal = d.objetivo, meta = d.meta,
                            creado = creado.toEpochDay(), pasos = d.pasos,
                            recordatorio = if (d.nombre == "Leer 20 minutos") 21 * 60 + 30 else null,
                        ),
                    )
                    app.repositorio.habito(id)?.let { Recordatorios.programar(app, it) }
                    var dia = creado
                    while (dia.isBefore(hoy)) {
                        val x = r.nextDouble()
                        when {
                            x < d.p -> app.repositorio.marcar(id, dia.toEpochDay(), Tipo.HECHO)
                            x < d.p + 0.06 -> app.repositorio.marcar(id, dia.toEpochDay(), Tipo.DESCANSO)
                        }
                        dia = dia.plusDays(1)
                    }
                }
            } finally {
                pendiente.finish()
            }
        }
    }
}
