package com.serenaesteve.shabit.dominio

import com.serenaesteve.shabit.recordatorios.Recordatorios
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.DayOfWeek.MONDAY
import java.time.DayOfWeek.SUNDAY
import java.time.Duration
import java.time.LocalDate
import java.time.LocalDateTime
import kotlin.math.PI
import kotlin.math.sin

class ProgresoTest {
    // Viernes 6 de noviembre de 2026.
    private val hoy = LocalDate.of(2026, 11, 6)
    private val nada = emptySet<Long>()
    private fun d(fecha: LocalDate) = fecha.toEpochDay()
    private fun atras(vararg n: Long) = n.map { d(hoy.minusDays(it)) }.toSet()
    private fun oct(dia: Int) = d(LocalDate.of(2026, 10, dia))

    @Test fun inicioDeSemanaSegunPreferencia() {
        assertEquals(LocalDate.of(2026, 11, 2), Progreso.inicioSemana(hoy, MONDAY))
        assertEquals(LocalDate.of(2026, 11, 1), Progreso.inicioSemana(hoy, SUNDAY))
    }

    @Test fun rachaDeDiasCuentaDesdeHoy() {
        assertEquals(3, Progreso.rachaDias(atras(0, 1, 2, 4), nada, hoy))
    }

    @Test fun rachaSigueVivaSiHoyAunNoEstaMarcado() {
        assertEquals(2, Progreso.rachaDias(atras(1, 2), nada, hoy))
        assertEquals(0, Progreso.rachaDias(atras(2, 3), nada, hoy))
    }

    @Test fun descansoNoRompeLaRachaNiSuma() {
        // Hecho hoy, descanso ayer, hecho anteayer y el día anterior: racha de 3.
        assertEquals(3, Progreso.rachaDias(atras(0, 2, 3), atras(1), hoy))
        // Hoy marcado como descanso: la racha sigue desde ayer.
        assertEquals(2, Progreso.rachaDias(atras(1, 2), atras(0), hoy))
    }

    @Test fun mejorRachaSaltaLosDescansos() {
        assertEquals(4, Progreso.mejorRachaDias(atras(0, 2, 3, 4, 5, 9, 10), nada))
        assertEquals(6, Progreso.mejorRachaDias(atras(0, 2, 3, 4, 5, 7), atras(1, 6)))
        assertEquals(0, Progreso.mejorRachaDias(nada, nada))
    }

    @Test fun hechasEstaSemana() {
        // Semana del lunes 2 al domingo 8: lunes 2, miércoles 4 y hoy viernes 6 (el 1 es de la semana anterior).
        assertEquals(3, Progreso.hechasEstaSemana(atras(0, 2, 4, 5), hoy, MONDAY))
    }

    @Test fun descansosRebajanElObjetivoDeLaSemana() {
        val lunes = LocalDate.of(2026, 10, 26)
        val inicio = oct(1)
        assertEquals(5, Progreso.objetivoDeSemana(lunes, inicio, 5, nada))
        // Con tres descansos solo quedan cuatro días posibles.
        assertEquals(4, Progreso.objetivoDeSemana(lunes, inicio, 5, setOf(oct(26), oct(27), oct(28))))
        // Una semana entera de descanso no cuenta.
        assertNull(Progreso.objetivoDeSemana(lunes, inicio, 5, (26..31).map { oct(it) }.toSet() + d(LocalDate.of(2026, 11, 1))))
    }

    @Test fun semanaDeVacacionesNoRompeLaRachaDeSemanas() {
        val creado = oct(12)
        val hechos = buildSet {
            for (k in 0 until 3) add(oct(12 + k * 2))       // semana del 12: cumplida
            for (k in 0 until 3) add(d(LocalDate.of(2026, 11, 2).plusDays(k * 2L))) // semana actual: cumplida
        }
        // Semana del 19: descanso entero. Semana del 26: cumplida.
        val descansos = (19..25).map { oct(it) }.toSet()
        val hechos2 = hechos + setOf(oct(26), oct(28), oct(30))
        assertEquals(3, Progreso.rachaSemanas(hechos2, descansos, hoy, 3, MONDAY, creado))
        assertEquals(3, Progreso.mejorRachaSemanas(hechos2, descansos, hoy, 3, MONDAY, creado))
    }

    @Test fun rachaDeSemanasNoSeRompePorLaSemanaEnCurso() {
        val creado = oct(12)
        val hechos = buildSet {
            listOf(12, 19, 26).forEach { lunes -> for (k in 0 until 3) add(oct(lunes + k * 2)) }
            add(d(LocalDate.of(2026, 11, 3)))
        }
        assertEquals(3, Progreso.rachaSemanas(hechos, nada, hoy, 3, MONDAY, creado))
    }

    @Test fun semanaDeCreacionIncompletaPideSoloLosDiasDisponibles() {
        val creado = oct(31)
        val hechos = setOf(oct(31), d(LocalDate.of(2026, 11, 1)))
        assertEquals(1, Progreso.rachaSemanas(hechos, nada, hoy, 5, MONDAY, creado))
        assertEquals(1f, Progreso.constancia(hechos, nada, hoy, 5, MONDAY, creado))
    }

    @Test fun constanciaNoCastigaLaSemanaQueNoHaTerminado() {
        val hechos = setOf(oct(19), oct(20), oct(28))
        assertEquals(0.5f, Progreso.constancia(hechos, nada, hoy, 2, MONDAY, oct(19)))
        assertNull(Progreso.constancia(nada, nada, hoy, 3, MONDAY, d(hoy)))
    }

    @Test fun recordatorioPasaAMananaSiLaHoraYaPaso() {
        val ahora = LocalDateTime.of(2026, 11, 6, 21, 0)
        assertEquals(Duration.ofMinutes(30), Recordatorios.retrasoHasta(21 * 60 + 30, ahora))
        assertEquals(Duration.ofHours(23), Recordatorios.retrasoHasta(20 * 60, ahora))
        assertEquals(Duration.ofHours(24), Recordatorios.retrasoHasta(21 * 60, ahora))
    }
}

class PasosTest {
    private val dia = 20_000L

    @Test fun primerValorDelDiaEsLaBase() {
        var e = Pasos.conContador(EstadoPasos(), 15_000f, dia)
        assertEquals(0, Pasos.deHoy(e, dia))
        e = Pasos.conContador(e, 16_240f, dia)
        assertEquals(1_240, Pasos.deHoy(e, dia))
    }

    @Test fun nuevoDiaEmpiezaDeCero() {
        val ayer = Pasos.conContador(Pasos.conContador(EstadoPasos(), 100f, dia - 1), 9_000f, dia - 1)
        val e = Pasos.conContador(ayer, 9_100f, dia)
        assertEquals(0, Pasos.deHoy(e, dia))
        assertEquals(0, Pasos.deHoy(ayer, dia))
    }

    @Test fun reinicioDelMovilNoPierdeLosPasos() {
        var e = Pasos.conContador(EstadoPasos(), 5_000f, dia)
        e = Pasos.conContador(e, 8_000f, dia)  // 3.000 pasos
        e = Pasos.conContador(e, 50f, dia)     // reinicio: el contador vuelve a empezar
        e = Pasos.conContador(e, 1_050f, dia)
        assertEquals(4_050, Pasos.deHoy(e, dia))
    }

    @Test fun detectorSumaPasos() {
        var e = Pasos.conDetector(EstadoPasos(), 1, dia)
        repeat(9) { e = Pasos.conDetector(e, 1, dia) }
        assertEquals(10, Pasos.deHoy(e, dia))
        assertEquals(1, Pasos.deHoy(Pasos.conDetector(e, 1, dia + 1), dia + 1))
    }

    @Test fun detectorCuentaUnPasoPorOscilacion() {
        val detector = DetectorPasos()
        var pasos = 0
        // 10 segundos caminando a 2 pasos por segundo, muestreado a 50 Hz.
        for (i in 0 until 500) {
            val t = i * 20L
            val z = 9.81f + 3.2f * sin(2 * PI * 2.0 * t / 1000.0).toFloat()
            if (detector.muestra(0f, 0f, z, t)) pasos++
        }
        assertTrue("contados $pasos", pasos in 19..21)
    }

    @Test fun detectorIgnoraElMovilQuieto() {
        val detector = DetectorPasos()
        var pasos = 0
        for (i in 0 until 500) if (detector.muestra(0.1f, 0.2f, 9.8f + (i % 3) * 0.05f, i * 20L)) pasos++
        assertEquals(0, pasos)
    }
}
