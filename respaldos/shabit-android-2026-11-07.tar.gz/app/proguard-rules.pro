# Room y WorkManager traen sus propias reglas; aquí no hace falta nada más.
